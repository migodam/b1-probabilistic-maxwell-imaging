"""Fresh scalar-TM blind-case generation, write-once prediction seal, and scoring.

Only `generate` imports the physical forward model or opens private material.
`seal` reads public case IDs and prediction JSON. `score` requires that seal.
Keep the private directory local and out of every solver upload.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import secrets
import time
import uuid

import numpy as np

HERE = Path(__file__).resolve().parents[1]
REPO = HERE.parents[1]
R4 = REPO / "research/research_z_alg_r4_diversity"


def dump_new(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")


def _shape(index: int, rng: np.random.Generator) -> np.ndarray:
    """Randomized new high-resolution geometry, area-averaged to 24x24."""
    n = 192
    y, x = np.mgrid[:n, :n]
    x = (x + .5)/n*2 - 1
    y = (y + .5)/n*2 - 1
    angle = rng.uniform(-.25, .25)
    c, s = np.cos(angle), np.sin(angle)
    u, v = c*x-s*y, s*x+c*y
    u -= rng.uniform(-.07, .07)
    v -= rng.uniform(-.07, .07)
    family = index % 4
    if family == 0:  # asymmetric elliptical annulus
        a, b = rng.uniform(.55, .71), rng.uniform(.45, .62)
        outside = (u/a)**2+(v/b)**2 <= 1
        inside = ((u-rng.uniform(-.12, .12))/(a*rng.uniform(.42, .58)))**2 + ((v-rng.uniform(-.12, .12))/(b*rng.uniform(.42, .58)))**2 < 1
        mask = outside & ~inside
    elif family == 1:  # unequal separated inclusions
        l = ((u+.38)/rng.uniform(.20, .29))**2+((v+.12)/rng.uniform(.27, .38))**2 <= 1
        r = ((u-.34)/rng.uniform(.23, .34))**2+((v-.21)/rng.uniform(.17, .29))**2 <= 1
        mask = l | r
    elif family == 2:  # interrupted curved bar
        radius = np.sqrt((u-.03)**2+(v+.01)**2)
        phi = np.mod(np.arctan2(v+.01, u-.03), 2*np.pi)
        mask = (np.abs(radius-rng.uniform(.49, .58)) < rng.uniform(.10, .15)) & (phi > .25) & (phi < 5.25)
    else:  # asymmetric three-stroke connected object
        horizontal = (np.abs(v+.38) < rng.uniform(.10, .15)) & (np.abs(u) < .58)
        diagonal = np.abs(v-(.8*u-.02)) < rng.uniform(.08, .13)
        vertical = (np.abs(u-.34) < rng.uniform(.09, .14)) & (np.abs(v) < .57)
        mask = horizontal | diagonal | vertical
    alpha = mask.reshape(24, 8, 24, 8).mean(axis=(1, 3))
    if not (.04 < np.mean(alpha >= .5) < .55):
        raise RuntimeError("Generated shape has implausible support")
    return alpha


def _model():
    spec = importlib.util.spec_from_file_location("r4_physics_blind_generation", R4 / "src/physics.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Model


def generate(public_out: Path, private_out: Path, operators: Path, n_shapes: int) -> None:
    if n_shapes not in (4, 12):
        raise ValueError("Frozen supported sizes: 4 pilot shapes or 12 full shapes")
    public_out, private_out = public_out.resolve(), private_out.resolve()
    if public_out == private_out or public_out in private_out.parents or private_out in public_out.parents:
        raise ValueError("Private truth and public data must be separate directories")
    if (public_out.exists() and any(public_out.iterdir())) or (private_out.exists() and any(private_out.iterdir())):
        raise FileExistsError("Preserve existing realization; both output directories must be empty")
    public_out.mkdir(parents=True, exist_ok=True)
    private_out.mkdir(parents=True, exist_ok=True)
    with np.load(operators, allow_pickle=False) as f:
        ops = {k: f[k] for k in f.files}
    if (ops["G"].shape, ops["E0"].shape, ops["S"].shape) != ((576, 576), (576, 12), (48, 576)):
        raise ValueError("Expected original 576/12/48 scalar-TM operators")
    rng_seed = secrets.randbits(128)
    rng = np.random.default_rng(rng_seed)
    Model = _model()
    model = Model(ops)
    public_records, private_records = [], []
    started = time.perf_counter()
    # The order and IDs are random. All shapes are selected before any inference.
    for i in range(n_shapes):
        alpha = _shape(i, rng)
        amplitude = 2.5 if i % 4 == 3 else 12.
        background = float(rng.uniform(.08, .15))
        material = background + amplitude*alpha.ravel()
        forward = model.forward(material, label="fresh_blind_generation")
        clean = forward["y"]
        direction = rng.normal(size=clean.shape)+1j*rng.normal(size=clean.shape)
        direction /= np.linalg.norm(direction)
        group_id = "case_" + uuid.uuid4().hex[:16]
        for noise in ("clean", "noisy"):
            obs_id = "obs_" + uuid.uuid4().hex[:16]
            Y = clean if noise == "clean" else clean + 1e-3*np.linalg.norm(clean)*direction
            np.savez_compressed(public_out / f"{obs_id}.npz", Y=Y,
                                observation_id=np.array(obs_id))
            private_records.append({"observation_id": obs_id, "group_id": group_id,
                                    "family_index": i % 4, "amplitude": amplitude,
                                    "background": background, "noise": noise,
                                    "truth_file": f"{obs_id}.npz"})
            np.savez_compressed(private_out / f"{obs_id}.npz", m=material,
                                alpha=alpha, mask=alpha >= .5, Y_clean=clean)
            public_records.append({"observation_id": obs_id,
                                   "public_path": f"{obs_id}.npz", "noise": noise})
    rng.shuffle(public_records)
    dump_new(public_out / "manifest.json", {
        "schema": "fbg-r2-fresh-blind-v1", "status": "FRESH_UNSCORED",
        "records": public_records, "operator_path": "operators.npz",
        "shape_count": n_shapes, "observation_count": len(public_records),
        "public_payload_keys": ["Y", "observation_id"],
        "solver_truth_access": "NONE", "planned_prediction_key": "m",
    })
    np.savez_compressed(public_out / "operators.npz", **ops)
    dump_new(private_out / "mapping_PRIVATE.json", {
        "schema": "fbg-r2-private-v1", "entropy": str(rng_seed),
        "records": private_records,
        "truth_policy": "LOCAL ONLY; score after every planned prediction disposition is sealed",
        "forward_solves": n_shapes, "generation_costcounts": dict(model.counts),
        "generation_wall_seconds": time.perf_counter()-started,
    })
    print(json.dumps({"status": "GENERATED_PRIVATE_TRUTH_HELD",
                      "public_manifest": str(public_out / "manifest.json"),
                      "observations": len(public_records), "forward_solves": n_shapes}))


def seal(manifest_path: Path, predictions_dir: Path, output: Path) -> None:
    manifest = json.loads(manifest_path.read_text())
    rows = []
    for record in manifest["records"]:
        ident = record["observation_id"]
        path = predictions_dir / f"{ident}.json"
        if path.exists():
            result = json.loads(path.read_text())
            m = result.get("m")
            finite = m is not None and np.asarray(m, float).size == 576 and np.isfinite(np.asarray(m, float)).all()
            disposition = "COMPLETE_FINITE" if finite else "FAILED_OR_NONFINITE"
        else:
            result, disposition = None, "NOT_RUN"
        rows.append({"observation_id": ident, "noise": record["noise"],
                     "disposition": disposition, "prediction": result})
    dump_new(output, {"schema": "fbg-r2-prediction-seal-v1",
                      "status": "ALL_PLANNED_PREDICTIONS_CLOSED",
                      "manifest": str(manifest_path), "sealed_unix": time.time(),
                      "planned": len(rows), "rows": rows, "truth_access": "NONE"})
    print(json.dumps({"sealed": len(rows), "finite": sum(r["disposition"] == "COMPLETE_FINITE" for r in rows),
                      "output": str(output)}))


def otsu(x: np.ndarray) -> float:
    x = np.asarray(x, float).ravel()
    low, high = float(x.min()), float(x.max())
    if high <= low:
        return high
    hist, edges = np.histogram(x, bins=256, range=(low, high))
    centers = (edges[:-1]+edges[1:])/2
    weight = np.cumsum(hist)
    moment = np.cumsum(hist*centers)
    n, total = len(x), moment[-1]
    denominator = weight*(n-weight)
    scores = np.divide((total*weight-n*moment)**2, denominator,
                       out=np.zeros(256), where=denominator > 0)
    return float(centers[int(np.argmax(scores))])


def iou(a: np.ndarray, b: np.ndarray) -> float:
    union = np.count_nonzero(a | b)
    return float(np.count_nonzero(a & b)/union) if union else 1.


def score(seal_path: Path, private_dir: Path, output: Path) -> None:
    closed = json.loads(seal_path.read_text())
    if closed.get("status") != "ALL_PLANNED_PREDICTIONS_CLOSED":
        raise ValueError("Prediction closure required before truth access")
    mapping = json.loads((private_dir / "mapping_PRIVATE.json").read_text())
    lookup = {r["observation_id"]: r for r in mapping["records"]}
    rows = []
    for sealed in closed["rows"]:
        ident = sealed["observation_id"]
        meta = lookup[ident]
        row = {"observation_id": ident, "group_id": meta["group_id"],
               "family_index": meta["family_index"], "amplitude": meta["amplitude"],
               "noise": meta["noise"], "disposition": sealed["disposition"],
               "material_gate": "NOT_RUN", "data_gate": "NOT_RUN", "joint_gate": "NOT_RUN"}
        pred = sealed["prediction"] or {}
        if sealed["disposition"] != "NOT_RUN":
            row["material_gate"] = row["data_gate"] = row["joint_gate"] = "FAIL"
        if sealed["disposition"] == "COMPLETE_FINITE":
            m = np.asarray(pred["m"], float).ravel()
            with np.load(private_dir / meta["truth_file"], allow_pickle=False) as f:
                truth, mask = f["m"].ravel(), f["mask"].ravel()
            rmse = float(np.sqrt(np.mean((m-truth)**2)))
            threshold = otsu(m)
            jaccard = iou(m > threshold, mask)
            residual = (pred.get("top1") or {}).get("relative_residual",
                         pred.get("relative_residual"))
            if residual is not None and not np.isfinite(residual):
                residual = None
            limit = .001 if meta["noise"] == "clean" else .003
            data_ok = residual is not None and residual <= limit
            material_ok = rmse/meta["amplitude"] <= .15 and jaccard >= .7
            row.update({"RMSE": rmse, "NRMSE": rmse/meta["amplitude"],
                        "MAE": float(np.mean(np.abs(m-truth))),
                        "IoU_Otsu": jaccard, "otsu_threshold_reconstruction_only": threshold,
                        "relative_data_residual": residual,
                        "data_gate": "PASS" if data_ok else "FAIL",
                        "material_gate": "PASS" if material_ok else "FAIL",
                        "joint_gate": "PASS" if data_ok and material_ok else "FAIL"})
        rows.append(row)
    dump_new(output, {"schema": "fbg-r2-blind-scores-v1",
                      "seal": str(seal_path), "truth_disclosed_only_after_seal": True,
                      "new_physics_LU": 0, "rows": rows,
                      "planned": len(rows),
                      "joint_pass": sum(r["joint_gate"] == "PASS" for r in rows),
                      "joint_fail": sum(r["joint_gate"] == "FAIL" for r in rows),
                      "not_run": sum(r["joint_gate"] == "NOT_RUN" for r in rows)})
    print(json.dumps({"rows": len(rows), "joint_pass": sum(r["joint_gate"] == "PASS" for r in rows),
                      "output": str(output)}))


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="command", required=True)
    g = sub.add_parser("generate")
    g.add_argument("--public-out", type=Path, required=True)
    g.add_argument("--private-out", type=Path, required=True)
    g.add_argument("--operators", type=Path, default=R4 / "public_data/operators.npz")
    g.add_argument("--shape-count", type=int, default=4)
    g.add_argument("--go", action="store_true")
    s = sub.add_parser("seal")
    s.add_argument("--manifest", type=Path, required=True)
    s.add_argument("--predictions", type=Path, required=True)
    s.add_argument("--output", type=Path, required=True)
    s.add_argument("--close", action="store_true")
    c = sub.add_parser("score")
    c.add_argument("--seal", type=Path, required=True)
    c.add_argument("--private-dir", type=Path, required=True)
    c.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    if a.command == "generate":
        if not a.go:
            ap.error("Fresh generation requires --go after design selection")
        generate(a.public_out, a.private_out, a.operators, a.shape_count)
    elif a.command == "seal":
        if not a.close:
            ap.error("Parent must close all planned prediction dispositions with --close")
        seal(a.manifest, a.predictions, a.output)
    else:
        score(a.seal, a.private_dir, a.output)


if __name__ == "__main__":
    main()
