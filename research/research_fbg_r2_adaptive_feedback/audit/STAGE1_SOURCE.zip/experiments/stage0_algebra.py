#!/usr/bin/env python3
"""One deterministic finite-matrix audit of feedback gauge and A17 algebra.

This is complex linear algebra only: no Maxwell solve, optimizer, GPU, GT, or
precision sweep. Run with the local NumPy/SciPy environment if available.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "audit" / "STAGE0_MATH.json"


def relerr(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / max(1.0, np.linalg.norm(a), np.linalg.norm(b)))


def objective(m: np.ndarray, g: np.ndarray, e: np.ndarray, s: np.ndarray,
              y: np.ndarray, b: np.ndarray) -> tuple[float, dict[str, np.ndarray]]:
    n = len(m)
    x = np.diag(m)
    q = np.linalg.solve(np.eye(n) - g @ x, e)
    j = x @ q
    r = s @ j - y
    f = q + b @ j  # transformed TOTAL field, not a new incident source
    h = f.conj().T @ f
    k = np.linalg.solve(h, np.eye(e.shape[1]))
    psi = float(np.trace(r @ k @ r.conj().T).real)
    return psi, dict(x=x, q=q, j=j, r=r, f=f, h=h, k=k)


def run() -> dict:
    rng = np.random.default_rng(20261030)

    def cm(shape, scale=1.0):
        return scale * (rng.normal(size=shape) + 1j * rng.normal(size=shape)) / np.sqrt(2.0)

    n, ns, nr, d = 6, 2, 4, 3
    m = np.array([0.31, 0.47, 0.60, 0.72, 0.83, 1.02])
    g = cm((n, n), 0.12)
    e = cm((n, ns))
    s = cm((nr, n))
    b = cm((n, n), 0.11)
    y = cm((nr, ns), 0.3)  # fixed observation matrix, independent of m
    direction = np.array([0.41, -0.25, 0.19, 0.32, -0.27, 0.36])
    eps = 1e-6
    psi, z = objective(m, g, e, s, y, b)
    x, q, j, r, f, k = (z[key] for key in ("x", "q", "j", "r", "f", "k"))
    ident = np.eye(n)
    mf = ident + b @ x
    a = ident + x @ b
    xt = np.linalg.solve(a, x)
    gt = g + b
    qt = np.linalg.solve(ident - gt @ xt, e)
    jt = xt @ qt

    # Physical directional current and total-field derivatives, fixed B.
    l = ident - x @ g
    t = np.linalg.solve(l, np.diag(direction) @ q)
    qh = g @ t
    fh_direct = b @ np.diag(direction) @ q + mf @ qh
    fh_short = (g + b) @ t
    w = r @ k
    v = f @ k @ (r.conj().T @ r) @ k
    adj = np.linalg.solve(l.conj().T, s.conj().T @ w - (g + b).conj().T @ v)
    gradient = 2.0 * np.real(np.sum(adj.conj() * q, axis=1))
    fd = (objective(m + eps * direction, g, e, s, y, b)[0]
          - objective(m - eps * direction, g, e, s, y, b)[0]) / (2 * eps)
    analytic = float(np.dot(gradient, direction))

    # Source-span projector derivative; unlike the gauge current, this can move.
    pinv_f = k @ f.conj().T
    proj = f @ pinv_f
    dproj = (ident - proj) @ fh_short @ pinv_f
    dproj += pinv_f.conj().T @ fh_short.conj().T @ (ident - proj)
    fp = objective(m + eps * direction, g, e, s, y, b)[1]["f"]
    fm = objective(m - eps * direction, g, e, s, y, b)[1]["f"]
    pp = fp @ np.linalg.solve(fp.conj().T @ fp, fp.conj().T)
    pm = fm @ np.linalg.solve(fm.conj().T @ fm, fm.conj().T)
    dproj_fd = (pp - pm) / (2 * eps)

    # Unrestricted static B=-G removes all transformed-field material variation.
    cancel = -g
    psi_cancel, z_cancel = objective(m, g, e, s, y, cancel)
    cancel_gradient_field_norm = float(np.linalg.norm((g + cancel) @ t))
    cancel_fd = (objective(m + eps * direction, g, e, s, y, cancel)[0]
                 - objective(m - eps * direction, g, e, s, y, cancel)[0]) / (2 * eps)

    # Another pathology: B=tI makes the proposal objective vanish by scaling.
    psi_zero_b, _ = objective(m, g, e, s, y, np.zeros_like(g))
    psi_scaled, z_scaled = objective(m, g, e, s, y, 1e4 * ident)

    # Noncommutation and conditioning examples separate algebraic from safe.
    wrong_order = np.linalg.solve(ident + b @ x, x)
    near_b = np.zeros((n, n), dtype=complex)
    near_b[0, 0] = -(1.0 - 1e-6) / m[0]
    near_mf = ident + near_b @ x
    nilpotent = np.zeros((n, n), dtype=complex)
    nilpotent[0, 1] = 20.0
    nonnormal_b = nilpotent @ np.linalg.inv(x)
    nonnormal_mf = ident + nonnormal_b @ x

    # Invertible source mixing preserves psi and P, while raw Frobenius data
    # loss changes for this nonunitary C.
    mix = np.array([[1.3, 0.4j], [0.1, 0.7]], dtype=complex)
    fmix, rmix = f @ mix, r @ mix
    kmix = np.linalg.solve(fmix.conj().T @ fmix, np.eye(ns))
    psi_mix = float(np.trace(rmix @ kmix @ rmix.conj().T).real)
    proj_mix = fmix @ kmix @ fmix.conj().T
    # R4-style production scaling is not invariant when recomputed after an
    # arbitrary nonunitary source mix; a frozen original-acquisition factor is.
    m_ref = np.full(n, 0.55)
    q_ref = objective(m_ref, g, e, s, y, np.zeros_like(g))[1]["q"]
    factor = 0.5 * (np.linalg.norm(q_ref)**2 / ns) / np.linalg.norm(y)**2
    factor_mix = 0.5 * (np.linalg.norm(q_ref @ mix)**2 / ns) / np.linalg.norm(y @ mix)**2
    regularizer = 0.2
    normalized = factor * psi + regularizer
    normalized_mix_recomputed = factor_mix * psi_mix + regularizer
    normalized_mix_frozen = factor * psi_mix + regularizer

    # Actual A17 shared-anchor Schur/Galerkin exchange algebra. Its material
    # injection is a separate matrix, not the feedback-design B above.
    basis, _ = np.linalg.qr(cm((n, 4)))
    core, old, new = basis[:, :2], basis[:, 2:3], basis[:, 3:4]
    inj = cm((n, d))
    core_res = core @ np.linalg.solve(core.conj().T @ l @ core, core.conj().T)
    k0 = core_res @ inj

    def schur(c):
        cbar = (ident - core_res @ l) @ c
        yc = s @ cbar
        nc = c.conj().T @ (inj - l @ k0)
        gamma = c.conj().T @ l @ cbar
        delta = yc @ np.linalg.solve(gamma, nc)
        u = np.column_stack((core, c))
        ku = u @ np.linalg.solve(u.conj().T @ l @ u, u.conj().T @ inj)
        return delta, s @ ku, gamma

    old_delta, jo, gamma_old = schur(old)
    new_delta, jn, gamma_new = schur(new)
    anchor = s @ k0
    exchange = new_delta - old_delta
    # Real material coordinates: stack complex data rather than treating each
    # illumination as an independent material parameter.
    jo_real = np.vstack((jo.real, jo.imag))
    jn_real = np.vstack((jn.real, jn.imag))
    residual_real = rng.normal(size=2 * nr)
    lam = np.diag([0.5, 0.8, 1.1])
    so = -np.linalg.solve(jo_real.T @ jo_real + lam, jo_real.T @ residual_real)
    sn = -np.linalg.solve(jn_real.T @ jn_real + lam, jn_real.T @ residual_real)
    dd = jn_real - jo_real
    delta_info = jo_real.T @ dd + dd.T @ jo_real + dd.T @ dd
    delta_offset = dd.T @ residual_real
    step_formula = -np.linalg.solve(jn_real.T @ jn_real + lam,
                                    delta_offset + delta_info @ so)

    checks = {
        "gauge_current_relative_error": relerr(jt, j),
        "gauge_total_field_relative_error": relerr(qt, mf @ q),
        "gauge_material_order_identity_relative_error": relerr(xt, x @ np.linalg.inv(ident + b @ x)),
        "noncommuting_wrong_order_gap": relerr(xt, wrong_order),
        "feedback_directional_identity_relative_error": relerr(fh_direct, fh_short),
        "gradient_directional_absolute_error": abs(analytic - fd),
        "gradient_directional_relative_error": abs(analytic - fd) / max(1.0, abs(analytic), abs(fd)),
        "projector_directional_relative_error": relerr(dproj, dproj_fd),
        "projector_directional_norm": float(np.linalg.norm(dproj)),
        "source_mixing_psi_relative_error": abs(psi_mix - psi) / max(1.0, abs(psi)),
        "source_mixing_projector_relative_error": relerr(proj_mix, proj),
        "source_mixing_raw_loss_ratio": float(np.linalg.norm(rmix)**2 / np.linalg.norm(r)**2),
        "source_mixing_recomputed_R4_factor_ratio": float(factor_mix / factor),
        "source_mixing_recomputed_normalized_objective_relative_change": float(
            abs(normalized_mix_recomputed - normalized) / max(1.0, abs(normalized))),
        "source_mixing_frozen_factor_objective_relative_error": float(
            abs(normalized_mix_frozen - normalized) / max(1.0, abs(normalized))),
        "cancel_field_minus_incident_relative_error": relerr(z_cancel["f"], e),
        "cancel_field_directional_norm": cancel_gradient_field_norm,
        "cancel_objective_directional_fd": float(cancel_fd),
        "scaled_psi_ratio_to_original": float(psi_scaled / psi_zero_b),
        "scaled_physical_residual_relative_error": relerr(z_scaled["r"], r),
        "near_pole_Mf_condition": float(np.linalg.cond(near_mf)),
        "nonnormal_BX_spectral_radius": float(max(abs(np.linalg.eigvals(nonnormal_b @ x)))),
        "nonnormal_Mf_condition": float(np.linalg.cond(nonnormal_mf)),
        "a17_old_schur_relative_error": relerr(jo, anchor + old_delta),
        "a17_new_schur_relative_error": relerr(jn, anchor + new_delta),
        "a17_exchange_relative_error": relerr(jn - jo, exchange),
        "a17_step_difference_relative_error": relerr(sn - so, step_formula),
        "a17_old_schur_condition": float(np.linalg.cond(gamma_old)),
        "a17_new_schur_condition": float(np.linalg.cond(gamma_new)),
    }
    tolerances = {
        "algebra_relative": 1e-10,
        "directional_relative": 1e-5,
        "gradient_absolute": 1e-5,
    }
    passes = {
        "gauge_and_order": max(checks[k] for k in (
            "gauge_current_relative_error", "gauge_total_field_relative_error",
            "gauge_material_order_identity_relative_error")) < tolerances["algebra_relative"],
        "noncommutation_witness": checks["noncommuting_wrong_order_gap"] > 1e-3,
        "directional_identity": checks["feedback_directional_identity_relative_error"] < tolerances["algebra_relative"],
        "gradient": checks["gradient_directional_relative_error"] < tolerances["directional_relative"]
                    and checks["gradient_directional_absolute_error"] < tolerances["gradient_absolute"],
        "projector_derivative": checks["projector_directional_relative_error"] < tolerances["directional_relative"]
                                and checks["projector_directional_norm"] > 1e-4,
        "source_basis_invariance": max(checks["source_mixing_psi_relative_error"],
                                       checks["source_mixing_projector_relative_error"]) < tolerances["algebra_relative"],
        "raw_loss_basis_caveat": abs(checks["source_mixing_raw_loss_ratio"] - 1.0) > 1e-2,
        "production_normalization_caveat": abs(checks["source_mixing_recomputed_R4_factor_ratio"] - 1.0) > 1e-2
                                           and checks["source_mixing_frozen_factor_objective_relative_error"]
                                           < tolerances["algebra_relative"],
        "cancel_counterexample": checks["cancel_field_minus_incident_relative_error"] < tolerances["algebra_relative"]
                                 and checks["cancel_field_directional_norm"] < tolerances["algebra_relative"]
                                 and abs(checks["cancel_objective_directional_fd"]) > 1e-4,
        "scale_degeneracy": checks["scaled_psi_ratio_to_original"] < 1e-5
                            and checks["scaled_physical_residual_relative_error"] < tolerances["algebra_relative"],
        "a17_schur_exchange_step": max(checks[k] for k in (
            "a17_old_schur_relative_error", "a17_new_schur_relative_error",
            "a17_exchange_relative_error", "a17_step_difference_relative_error")) < tolerances["algebra_relative"],
    }
    result = {
        "status": "PASS" if all(passes.values()) else "FAIL",
        "scope": "one deterministic small complex matrix audit; no Maxwell physics or imaging inference",
        "seed": 20261030,
        "dimensions": {"state": n, "sources": ns, "receivers": nr, "real_material_directions_A17": d},
        "finite_difference_step": eps,
        "checks": checks,
        "passes": passes,
        "tolerances": tolerances,
        "objective_values": {"feedback": psi, "B_zero_original": psi_zero_b,
                             "B_minus_G": psi_cancel, "B_large_positive": psi_scaled},
        "safety_boundary": "conditioning examples demonstrate risk, not a general admissible B set",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "passes": passes,
                      "audit": str(OUT)}, indent=2))
    return result


if __name__ == "__main__":
    run()
