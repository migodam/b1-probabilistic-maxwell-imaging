Compile manuscript_ip.tex with Tectonic, or with XeLaTeX twice. The bibliography is included as TeX. Figure files are under figures/.
