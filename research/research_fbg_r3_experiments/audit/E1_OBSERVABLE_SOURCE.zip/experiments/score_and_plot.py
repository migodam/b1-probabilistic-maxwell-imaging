#!/usr/bin/env python3
"""Post-closure material scoring. Never import this module in an online runner.

All private file access occurs in main(), after the explicit closure guard.
No optimization or new Maxwell solve is performed. Physical residuals come from
sealed predictions / paid endpoint ledgers. Candidate GT scores are oracle-only.
"""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import csv
import gzip
import json
import math
import numpy as np

STUDY = Path(__file__).resolve().parents[1]
DEFAULT_PRIVATE = STUDY.parents[3] / 'fbg_r3e_private_20261101'


def clean(value):
    if isinstance(value, np.ndarray): return clean(value.tolist())
    if isinstance(value, np.generic): return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value): return None
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [clean(v) for v in value]
    return value


def otsu_mask(material):
    """256-bin histogram Otsu; uniform material has empty foreground."""
    material = np.asarray(material, float).ravel()
    if not np.all(np.isfinite(material)): raise ValueError('Nonfinite material')
    if np.ptp(material) <= 1e-12: return np.zeros(material.size, bool), float(material[0])
    hist, edges = np.histogram(material, bins=256)
    centers = (edges[1:] + edges[:-1]) / 2
    weight = np.cumsum(hist)
    moment = np.cumsum(hist * centers)
    denom = weight * (weight[-1] - weight)
    between = np.full(hist.size, -np.inf)
    good = denom > 0
    between[good] = (moment[-1] * weight[good] - moment[good] * weight[-1])**2 / denom[good]
    threshold = float(centers[int(np.argmax(between))])
    return material > threshold, threshold


def material_metrics(material, truth, amplitude, support):
    material, truth = np.asarray(material, float).ravel(), np.asarray(truth, float).ravel()
    if material.shape != truth.shape: raise ValueError('Prediction / truth dimensions differ')
    fg, threshold = otsu_mask(material)
    support = np.asarray(support, bool).ravel()
    union = np.count_nonzero(fg | support)
    iou = np.count_nonzero(fg & support) / union if union else 1.
    nrmse = float(np.linalg.norm(material - truth) / np.sqrt(truth.size) / amplitude)
    return dict(amplitude_normalized_nrmse=nrmse, otsu_iou=float(iou),
                otsu_threshold=threshold, material_nrmse_pass=bool(nrmse <= .15),
                image_pass=bool(nrmse <= .15 and iou >= .7))


def npz_dict(path):
    if not path.exists(): return {}
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}


def write_csv(path, rows):
    if not rows: return
    columns = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='') as file:
        writer = csv.DictWriter(file, columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(clean(v), sort_keys=True) if isinstance(v, (dict, list)) else clean(v)
                             for k, v in row.items()})


def group_id(row):
    parts = [str(row['method'])]
    for key in ('k', 'budget_label', 'budget', 'wall_budget', 'noise_label', 'noise'):
        if key in row: parts.append(f'{key}={row[key]}')
    return ' / '.join(parts)


def endpoint_metadata(prefix):
    """Read already-paid candidate physical scores; never recompute forward maps."""
    path = Path(str(prefix) + '_ledger.jsonl.gz')
    out = {}
    if path.exists():
        with gzip.open(path, 'rt') as file:
            for line in file:
                run = json.loads(line)
                for i, endpoint in enumerate(run.get('corrected', [])):
                    out[run['run_id'] + f'_candidate{i}'] = {
                        'relative_residual': endpoint.get('relative_residual'),
                        'provenance': endpoint.get('provenance', {})}
    return out


def cluster_summary(rows):
    by_cluster = defaultdict(list)
    for row in rows: by_cluster[row['object_id']].append(row)
    clusters = []
    for oid, selected in sorted(by_cluster.items()):
        good = [r for r in selected if r.get('amplitude_normalized_nrmse') is not None]
        clusters.append(dict(object_id=oid, run_count=len(selected),
                             data_pass_fraction=float(np.mean([r['data_pass'] for r in selected])),
                             joint_pass_fraction=float(np.mean([r['joint_pass'] for r in selected])),
                             median_nrmse=float(np.median([r['amplitude_normalized_nrmse'] for r in good])) if good else None,
                             median_iou=float(np.median([r['otsu_iou'] for r in good])) if good else None))
    # Intervals describe finite-object resampling only, not population inference.
    values = np.array([r['joint_pass_fraction'] for r in clusters])
    rng = np.random.default_rng(20261101)
    interval = np.quantile(rng.choice(values, (10000, len(values)), replace=True).mean(1), [.025, .975]) if len(values) else [None, None]
    return dict(object_count=len(clusters), clusters=clusters,
                equal_object_mean_joint_pass=float(np.mean(values)) if len(values) else None,
                object_bootstrap_95_interval=clean(interval),
                inference_scope='Descriptive finite-object resampling; shared shapes/amplitudes/grids are not a population sample.')


def summarize(rows):
    groups = defaultdict(list)
    for row in rows: groups[row['group']].append(row)
    summary = []
    for group, selected in sorted(groups.items()):
        good = [r for r in selected if r.get('amplitude_normalized_nrmse') is not None]
        oracle = [r for r in selected if r.get('oracle_best_image_nrmse') is not None]
        summary.append(dict(group=group, runs=len(selected), failures=sum(r['score_status'] != 'SCORED' for r in selected),
                            execution_failures=sum('FAIL' in str(r.get('run_status', '')) or 'ERROR' in str(r.get('run_status', '')) for r in selected),
                            data_passes=sum(r['data_pass'] for r in selected), image_passes=sum(r['image_pass'] for r in selected),
                            joint_passes=sum(r['joint_pass'] for r in selected),
                            material_data_passes=sum(r.get('material_data_pass', False) for r in selected),
                            material_data_pass_but_iou_fail=sum(r.get('material_data_pass', False) and not r['image_pass'] for r in selected),
                            data_pass_image_fail=sum(r['data_pass'] and not r['image_pass'] for r in selected),
                            median_nrmse=float(np.median([r['amplitude_normalized_nrmse'] for r in good])) if good else None,
                            median_iou=float(np.median([r['otsu_iou'] for r in good])) if good else None,
                            oracle_image_passes=sum(r.get('oracle_any_image_pass', False) for r in selected),
                            oracle_joint_passes=sum(r.get('oracle_any_joint_pass', False) for r in selected),
                            oracle_joint_coverage_runs=sum(r.get('oracle_joint_coverage_complete', False) for r in selected),
                            oracle_joint_passes_status='EXACT' if all(r.get('oracle_joint_coverage_complete', False) for r in selected) else 'LOWER_BOUND_MISSING_PHYSICAL_RESIDUAL',
                            oracle_median_best_nrmse=float(np.median([r['oracle_best_image_nrmse'] for r in oracle])) if oracle else None,
                            wall_seconds=sum(r.get('wall_seconds', 0.) or 0. for r in selected),
                            model_cost=dict(sum((Counter(r.get('model_cost', {})) for r in selected), Counter())),
                            actual_corrected_seed_counts=dict(Counter(str(r.get('actual_corrected_seeds', 'NOT_RECORDED')) for r in selected)),
                            object_cluster=cluster_summary(selected)))
    return summary


def cost_rows(batch, rows):
    output = []
    for row in rows:
        counts = row.get('model_cost', {})
        aux = row.get('kernel_algebraic_counts', row.get('auxiliary_counts', {}))
        if not aux and isinstance(row.get('solver_cost'), dict):
            aux = row['solver_cost'].get('auxiliary', row['solver_cost'])
        output.append(dict(batch=batch, run_id=row['run_id'], group=group_id(row),
                           status=row.get('status'), wall_seconds=row.get('wall_seconds'),
                           LU=counts.get('LU', 0), actual_complex_RHS=counts.get('actual_complex_RHS', 0),
                           source_RHS=counts.get('source_RHS', 0), receiver_transpose_RHS=counts.get('receiver_transpose_RHS', 0),
                           support_setup_RHS=counts.get('support_setup_RHS', 0),
                           QR=aux.get('pivoted_QR', 0), green_dense_matrix_products=aux.get('green_dense_matrix_products', 0),
                           actual_proposed_seeds=row.get('proposal_count'), actual_corrected_seeds=row.get('corrected_count'),
                           phase_wall=row.get('phase_wall', {}), model_counts=counts, auxiliary_counts=aux,
                           setup_scope='Run costs as recorded; shared operator assembly is separate, not repeated per run.'))
    return output


def plots(batch, scored, summaries, mapping, truths, materials, raw_rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures = STUDY / 'figures'
    figures.mkdir(exist_ok=True)
    labels = [s['group'] for s in summaries]
    width = max(10, len(labels) * .9)
    fig, axes = plt.subplots(1, 3, figsize=(width, 4.4), layout='constrained')
    x = np.arange(len(summaries))
    for i, (field, title) in enumerate((('data_passes', 'Physical data PASS'), ('joint_passes', 'Joint image + data PASS'), ('median_nrmse', 'Median amplitude-normalized NRMSE'))):
        vals = [(s[field] / s['runs'] if i < 2 else (s[field] if s[field] is not None else np.nan)) for s in summaries]
        axes[i].bar(x, vals, color='#267c9e')
        axes[i].set_xticks(x, labels, rotation=65, ha='right', fontsize=7)
        axes[i].set_title(title)
        if i < 2: axes[i].set_ylim(0, 1)
        else: axes[i].axhline(.15, color='crimson', linestyle='--')
    fig.suptitle(f'{batch.upper()}: all sealed runs; finite object clusters, shared starts/layouts')
    fig.savefig(figures / f'{batch}_scores_summary.png', dpi=165)
    plt.close(fig)
    # All-object visual panels: selection uses only the online physical score.
    raw_lookup = {r['run_id']: r for r in raw_rows}
    all_groups = sorted({r['group'] for r in scored})
    cases = sorted({r['case_id'] for r in scored})
    for side in sorted({mapping[c]['side'] for c in cases}):
        for layout in sorted({mapping[c]['layout'] for c in cases if mapping[c]['side'] == side}):
            case_ids = sorted([c for c in cases if mapping[c]['side'] == side and mapping[c]['layout'] == layout],
                              key=lambda c: (mapping[c]['shape'], mapping[c]['amplitude']))
            for page in range((len(all_groups) + 7)//8):
                page_groups = all_groups[page*8:(page+1)*8]
                fig, axes = plt.subplots(len(case_ids), len(page_groups)+1,
                    figsize=(2.45*(len(page_groups)+1), 2.55*len(case_ids)), squeeze=False, layout='constrained')
                for ri, case in enumerate(case_ids):
                    meta = mapping[case]
                    truth = truths[meta['object_id']]['m'].reshape(side, side)
                    axes[ri, 0].imshow(truth, origin='lower', vmin=.02, vmax=20, cmap='viridis', interpolation='nearest')
                    axes[ri, 0].set_title(f"GT: {meta['shape']}, amp={meta['amplitude']:g}", fontsize=9)
                    for ci, group in enumerate(page_groups, 1):
                        possible = [r for r in scored if r['case_id'] == case and r['group'] == group and r['run_id'] in materials]
                        if not possible:
                            axes[ri, ci].text(.5,.5,'FAILED / MISSING',ha='center',va='center',transform=axes[ri,ci].transAxes)
                            continue
                        def online_score(row):
                            raw = raw_lookup[row['run_id']]
                            value = raw.get('score', raw.get('online_score', np.inf))
                            return value if value is not None else np.inf
                        chosen = min(possible, key=lambda r: (online_score(r), r['run_id']))
                        im = axes[ri, ci].imshow(materials[chosen['run_id']].reshape(side, side), origin='lower',
                                                vmin=.02, vmax=20, cmap='viridis', interpolation='nearest')
                        axes[ri, ci].set_title(f"{group}\ns={chosen.get('start','?')}; N={chosen['amplitude_normalized_nrmse']:.3f}; IoU={chosen['otsu_iou']:.2f}\nr={chosen['relative_residual']:.2g}; {'PASS' if chosen['joint_pass'] else ('IoU FAIL' if chosen.get('material_data_pass') else 'FAIL')}", fontsize=7)
                    for ax in axes[ri]: ax.set_xticks([]); ax.set_yticks([])
                fig.suptitle(f'{batch.upper()} / {side}×{side} / {layout}: lowest online physical score across shared starts; scale [.02,20]', fontsize=11)
                fig.savefig(figures / f'{batch}_materials_side{side}_{layout}_p{page+1}.png', dpi=150)
                plt.close(fig)


def load_sealed_results(result_path):
    closed = json.loads(result_path.read_text())
    if 'CLOSED' not in closed.get('status', ''):
        raise SystemExit(f'Result artifact has no closed-predictions state: {result_path}')
    prefix = Path(str(result_path).removesuffix('_results.json'))
    raw_rows = closed['rows']
    if result_path.name == 'SUMMARY.json':
        materials, predictions, candidates, endpoints = {}, {}, {}, {}
        for raw in raw_rows:
            rid = raw['run_id']
            saved = npz_dict(result_path.parent / (rid+'.npz'))
            if 'm' in saved: materials[rid] = saved['m']
            if 'prediction' in saved: predictions[rid] = saved['prediction']
            detail_path = result_path.parent / (rid+'.json.gz')
            metadata = []
            if detail_path.exists():
                with gzip.open(detail_path, 'rt') as file:
                    detail = json.load(file)
                metadata = detail.get('candidates', [])
            keys = []
            for i, cm in enumerate(saved.get('candidates', [])):
                key = rid+f'_candidate{i}'
                candidates[key] = cm
                keys.append(key)
                em = metadata[i] if i < len(metadata) else {}
                residual = em.get('relative_residual', em.get('physical_relative_residual'))
                if residual is None and str(em.get('tag', '')).startswith('common_corrector_'):
                    incumbent_records = [h for h in em.get('history', []) if h.get('physical_score') is not None and h.get('relative_residual') is not None]
                    if incumbent_records:
                        residual = min(incumbent_records, key=lambda h: h['physical_score'])['relative_residual']
                # The native corrector's incumbent archive stores physical score;
                # recover its already-paid residual from the matching history.
                if residual is None and em.get('physical_score') is not None:
                    for h in detail.get('history', []):
                        if h.get('physical_score') == em['physical_score']:
                            residual = h.get('relative_residual')
                            break
                endpoints[key] = dict(relative_residual=residual, provenance=em.get('tag', em.get('provenance')))
            raw['closed_candidate_material_keys'] = keys
            raw.setdefault('score', raw.get('physical_score'))
    else:
        materials = npz_dict(Path(str(prefix)+'_materials.npz'))
        predictions = npz_dict(Path(str(prefix)+'_predictions.npz'))
        candidates = npz_dict(Path(str(prefix)+'_candidate_materials.npz'))
        endpoints = endpoint_metadata(prefix)
    return closed, raw_rows, materials, predictions, candidates, endpoints


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--batch', required=True, choices=['e1', 'e2', 'e3'])
    ap.add_argument('--results', required=True, type=Path, nargs='+')
    ap.add_argument('--private-dir', default=DEFAULT_PRIVATE, type=Path)
    ap.add_argument('--public-dir', default=STUDY/'data/e1_public', type=Path)
    ap.add_argument('--authorize-closed', required=True, help='Must equal PREDICTIONS_CLOSED; parent authorization required.')
    ap.add_argument('--no-plots', action='store_true')
    ap.add_argument('--tag', help='Output/ledger tag; defaults to batch.')
    ap.add_argument('--classification', default='POST_CLOSURE_CONTROLLED_STUDY')
    args = ap.parse_args()
    tag = args.tag or args.batch
    if args.authorize_closed != 'PREDICTIONS_CLOSED': raise SystemExit('Private scoring requires explicit parent closure authorization')
    raw_rows, materials, predictions, candidates, endpoints = [], {}, {}, {}, {}
    source_records = []
    run_ids = set()
    for result_path in args.results:
        closed, rows, mm, pp, cc, ee = load_sealed_results(result_path)
        overlap = run_ids.intersection(r['run_id'] for r in rows)
        if overlap: raise SystemExit(f'Duplicate run IDs across scoring inputs: {sorted(overlap)[:3]}')
        run_ids.update(r['run_id'] for r in rows)
        raw_rows.extend(rows)
        materials.update(mm); predictions.update(pp); candidates.update(cc); endpoints.update(ee)
        source_records.append(dict(path=str(result_path), status=closed['status'],
                                   batch_wall=closed.get('batch_wall', closed.get('elapsed_wall_seconds')),
                                   workers=closed.get('workers', 1)))
    # First private access. Do not move above both closure checks.
    mapping_rows = json.loads((args.private_dir/'mapping.json').read_text())
    mapping = {r['case_id']: r for r in mapping_rows}
    selected_case_ids = {r['case_id'] for r in raw_rows}
    selected_mapping = [r for r in mapping_rows if r['case_id'] in selected_case_ids]
    truths = {r['object_id']: npz_dict(args.private_dir/r['truth_file']) for r in selected_mapping}
    gate_diagnostics = {}
    diagnostic_path = STUDY/'results/gt_gate_diagnostic_scores.json'
    if diagnostic_path.exists():
        gate_diagnostics = json.loads(diagnostic_path.read_text()).get('objects', {})
    for oid, truth in truths.items():
        if oid not in gate_diagnostics:
            self_mask, threshold = otsu_mask(truth['m'])
            stored = np.asarray(truth['mask'], bool).ravel()
            union = np.count_nonzero(self_mask | stored)
            meta = next(r for r in selected_mapping if r['object_id'] == oid)
            gate_diagnostics[oid] = dict(object_id=oid, side=meta['side'], shape=meta['shape'], amplitude=meta['amplitude'],
                gt_self_otsu_iou=float(np.count_nonzero(self_mask & stored)/union) if union else 1.,
                gt_self_otsu_threshold=threshold, stored_support_rule='high-resolution occupancy > .35')
    diagnostic_path.write_text(json.dumps(dict(status='OFFLINE_GATE_DIAGNOSTIC_AFTER_AUTHORIZED_CLOSURE',
        physical_calls=0, gates_changed=False, objects=gate_diagnostics), indent=2)+'\n')
    scored, candidate_scores = [], []
    for raw in raw_rows:
        meta = mapping[raw['case_id']]
        truth = truths[meta['object_id']]
        row = {k: raw[k] for k in ('run_id', 'case_id', 'side', 'layout', 'start', 'method', 'k', 'budget', 'budget_label', 'noise', 'noise_label', 'wall_budget') if k in raw}
        row.update(object_id=meta['object_id'], shape=meta['shape'], amplitude=meta['amplitude'],
                   group=group_id(raw), run_status=raw.get('status'), score_status='MISSING_PREDICTION',
                   relative_residual=raw.get('relative_residual'), wall_seconds=raw.get('wall_seconds'),
                   model_cost=raw.get('model_cost', {}), actual_corrected_seeds=raw.get('corrected_count'),
                   data_pass=False, image_pass=False, material_nrmse_pass=False, material_data_pass=False, joint_pass=False)
        noise = raw.get('noise_level', raw.get('noise', 0.))
        noisy = str(raw.get('noise_label', '')).lower() not in ('', 'clean', 'none', '0') or (isinstance(noise, (float, int)) and noise > 0)
        gate = .003 if noisy else .001
        row['physical_data_gate'] = gate
        if raw['run_id'] in materials:
            m = materials[raw['run_id']]
            try:
                row.update(material_metrics(m, truth['m'], meta['amplitude'], truth['mask']))
                row['score_status'] = 'SCORED'
                if raw['run_id'] in predictions:
                    # Runner may specify noisy observation used in its sealed data residual.
                    if not noisy:
                        obs = npz_dict(args.public_dir/f"{raw['case_id']}.npz")['Y']
                        measured = float(np.linalg.norm(predictions[raw['run_id']] - obs)/np.linalg.norm(obs))
                        row['saved_prediction_residual'] = measured
                        row['residual_record_difference'] = abs(measured - row['relative_residual']) if row['relative_residual'] is not None else None
                        row['relative_residual'] = measured
                residual = row['relative_residual']
                row['data_pass'] = bool(residual is not None and np.isfinite(residual) and residual <= gate)
                row['material_data_pass'] = bool(row['material_nrmse_pass'] and row['data_pass'])
                row['joint_pass'] = bool(row['image_pass'] and row['data_pass'])
                row['joint_failure_cause'] = 'PASS' if row['joint_pass'] else ('IOU_GATE_ONLY' if row['material_data_pass'] else 'MATERIAL_OR_DATA_GATE')
            except (ValueError, TypeError) as exc:
                row.update(score_status='INVALID_MATERIAL', scoring_error=str(exc), image_pass=False)
        pool = []
        pool_materials = []
        for key in raw.get('closed_candidate_material_keys', [k for k in candidates if k.startswith(raw['run_id']+'_candidate')]):
            if key not in candidates: continue
            cm = material_metrics(candidates[key], truth['m'], meta['amplitude'], truth['mask'])
            em = endpoints.get(key, {})
            residual = em.get('relative_residual')
            cm.update(run_id=raw['run_id'], candidate_key=key, relative_residual=residual,
                      data_pass=bool(residual is not None and residual <= gate), provenance=em.get('provenance'))
            cm['joint_pass'] = bool(cm['image_pass'] and cm['data_pass'])
            candidate_scores.append(cm)
            if not any(np.array_equal(candidates[key], old) for old in pool_materials):
                pool.append(cm)
                pool_materials.append(candidates[key])
        # Include selected online endpoint: it can be the retained anchor, outside corrected pool.
        corrected_distinct = len(pool)
        if row['score_status'] == 'SCORED':
            matches = [i for i, old in enumerate(pool_materials) if np.array_equal(materials[row['run_id']], old)]
            if matches:
                # An archived endpoint may omit its paid residual; the selected
                # incumbent's sealed prediction supplies that exact endpoint.
                for i in matches:
                    pool[i].update(relative_residual=row['relative_residual'], data_pass=row['data_pass'], joint_pass=row['joint_pass'])
            else:
                pool.append(row)
        row.update(oracle_pool_size_including_online=len(pool),
                   oracle_corrected_candidate_count=corrected_distinct,
                   oracle_best_image_nrmse=min((r['amplitude_normalized_nrmse'] for r in pool), default=None),
                   oracle_any_image_pass=any(r['image_pass'] for r in pool),
                   oracle_any_joint_pass=any(r['joint_pass'] for r in pool),
                   oracle_joint_coverage_complete=all(r.get('relative_residual') is not None for r in pool))
        scored.append(row)
    summaries = summarize(scored)
    result = dict(status='POST_CLOSURE_SCORED', batch=args.batch, tag=tag, classification=args.classification, result_sources=source_records,
                  private_truth_opened_after_parent_closure=True,
                  private_truth_object_ids_loaded=sorted(truths),
                  offline_gt_gate_diagnostics={oid:gate_diagnostics[oid] for oid in truths},
                  gt_diagnostic_scope='Offline self-Otsu versus stored occupancy support only; no physical calls and no gate change.',
                  gates=dict(amplitude_normalized_nrmse=.15, otsu_iou=.7, clean_relative_data=.001, noisy_relative_data=.003),
                  definitions=dict(nrmse='sqrt(mean((m-m_gt)^2)) / declared contrast amplitude (8 or 18)',
                      support='Stored high-resolution occupancy > .35; predicted foreground by 256-bin histogram Otsu',
                      oracle='Best image NRMSE / any joint pass among sealed endpoints plus selected online incumbent; GT used only here. Joint-pass counts are known-pass lower bounds if physical residual coverage is incomplete.',
                      visualization='Lowest online physical score among shared starts; all material panels use [.02,20].',
                      independence='Object IDs cluster two layouts and five starts; grid/shape families are exposed, not population inference.'),
                  summaries=summaries, rows=scored, candidate_scores=candidate_scores,
                  failed_or_joint_failed_runs=[r['run_id'] for r in scored if not r['joint_pass']])
    if args.batch == 'e1':
        result['truth_access_deviation_record'] = 'audit/TRUTH_ACCESS_DEVIATION.md'
    if tag == 'e1_initial':
        result['initial_n1_capacity_failure'] = dict(classification='IMPLEMENTATION_CAPACITY_FAILURE',
            record='audit/N1_INITIAL_REPRESENTABILITY.json',
            inference='Initial N1 does not adequately evaluate normal-direction mechanism; retained, not a theory refutation.')
    output = STUDY/'results'/f'{tag}_scores'
    output.with_suffix('.json').write_text(json.dumps(clean(result), indent=2)+'\n')
    write_csv(output.with_suffix('.csv'), scored)
    ledger_path = STUDY/'results/COST_LEDGER.csv'
    previous = []
    if ledger_path.exists():
        with ledger_path.open() as file: previous = [r for r in csv.DictReader(file) if r['batch'] != tag]
    setup_rows = []
    if not any(r['batch'] == 'shared_setup' for r in previous):
        manifest_path = STUDY/'audit/SOURCE_MANIFEST.json'
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text())
            setup_rows.append(dict(batch='shared_setup', run_id='public_data_generation', group='shared setup',
                                   status='RECORDED', wall_seconds=manifest.get('generation_wall'),
                                   LU=None, actual_complex_RHS=None,
                                   setup_scope='Data generation wall includes original Green assembly and observation creation; physical counter totals not in SOURCE_MANIFEST. Shared once, excluded from inference sum.'))
    write_csv(ledger_path, previous + setup_rows + cost_rows(tag, raw_rows))
    if not args.no_plots and args.batch in ('e1', 'e3'):
        plots(tag, scored, summaries, mapping, truths, materials, raw_rows)
    print(json.dumps(clean(dict(batch=args.batch, runs=len(scored), objects=len({r['object_id'] for r in scored}),
                               summaries=[{k:s[k] for k in ('group','runs','data_passes','joint_passes','median_nrmse','oracle_joint_passes')} for s in summaries],
                               output=str(output.with_suffix('.json')))), indent=2))


if __name__ == '__main__': main()
