"""Common public current pool and two-sided material-task release selection."""
from __future__ import annotations

import numpy as np
from scipy import linalg

try:
    from .current_normal import spatial_modes, current_action, normal_diagnostic, quotient_normal_signature
    from .joint_current_model import JointCurrentModel, whiten_data, regularizer
    from .profile_schur import profile_schur, release_candidate, physical_task_gain
except ImportError:
    from current_normal import spatial_modes, current_action, normal_diagnostic, quotient_normal_signature
    from joint_current_model import JointCurrentModel, whiten_data, regularizer
    from profile_schur import profile_schur, release_candidate, physical_task_gain


def _orth_columns(U, against=None, count=None):
    U = np.asarray(U, complex)
    if U.ndim == 1:
        U = U[:, None]
    if against is not None and against.shape[1]:
        U = U - against @ (against.conj().T @ U)
        U = U - against @ (against.conj().T @ U)
    if not U.shape[1]:
        return U
    u, s, _ = linalg.svd(U, full_matrices=False, check_finite=False)
    rank = int(np.count_nonzero(s > 1e-11 * s.max(initial=0)))
    return u[:, :min(rank, count) if count is not None else rank]


def _fourier_atoms(shape):
    coordinates = np.indices(shape).reshape(len(shape), -1).T
    frequencies = np.indices(shape).reshape(len(shape), -1).T
    centered = np.where(frequencies <= np.asarray(shape) / 2, frequencies, frequencies - np.asarray(shape))
    order = np.argsort(np.sum(centered ** 2, axis=1), kind="stable")
    for k in order:
        yield np.exp(2j * np.pi * (coordinates / np.asarray(shape)) @ centered[k]) / np.sqrt(np.prod(shape))


def build_common_pool(model, Y, m, state, config=None, cost=None):
    """All selectors receive these exact same equal-real-capacity candidates.

    Fourier, receiver, Green-Krylov and seeded random atoms use only public
    operators, observations and the common anchor. Acquisition is charged.
    ``backbone_receiver_atoms='observable'`` retains all right singular vectors
    above ``backbone_receiver_rtol`` (default 1e-3, matching mature CIE).
    Integer receiver counts preserve the original experiment configuration.
    """
    cfg = config or {}
    n, p = model.E.shape
    shape = tuple(model.shape) if np.prod(model.shape) == n else (n,)
    _, receiver_singular, vh = linalg.svd(model.S, full_matrices=False, check_finite=False)
    receiver = vh.conj().T
    receiver_setting = cfg.get("backbone_receiver_atoms", 1)
    observable = receiver_setting == "observable"
    receiver_rtol = float(cfg.get("backbone_receiver_rtol", cfg.get("dpcs_rtol", 1e-3)))
    if observable:
        if not 0.0 < receiver_rtol < 1.0:
            raise ValueError("Observable receiver cutoff must lie in (0,1)")
        nr = int(np.count_nonzero(receiver_singular > receiver_rtol * receiver_singular[0])) if len(receiver_singular) else 0
    else:
        nr = min(int(receiver_setting), receiver.shape[1])
    nf = int(cfg.get("backbone_fourier_atoms", 1))
    fourier = list(_fourier_atoms(shape))
    core = _orth_columns(np.column_stack([receiver[:, :nr], np.column_stack(fourier[:nf])]) if nf else receiver[:, :nr])
    def candidate_orth(U, against, count=None):
        if not observable:
            return _orth_columns(U, against, count)
        # Large observable backbones make exact-span proposals common. Reference
        # the original atoms when testing quotient rank, never roundoff alone.
        U = np.asarray(U, complex)
        if U.ndim == 1:
            U = U[:, None]
        reference = float(np.linalg.norm(U))
        for _ in range(2):
            U = U - against @ (against.conj().T @ U)
        u, s, _ = linalg.svd(U, full_matrices=False, check_finite=False)
        rank = int(np.count_nonzero(s > 1e-11 * max(reference, float(s.max(initial=0)))))
        return u[:, :min(rank, count) if count is not None else rank]
    # The removable group is explicit and has the same real capacity as a proposal.
    k = int(cfg.get("group_atoms", 1))
    q = int(cfg.get("pool_groups", 8))
    rng = np.random.default_rng(int(cfg.get("random_seed", 20261101)))
    source = model.S.conj().T @ (state["Y"] - Y)
    if cost:
        cost.add("receiver_transpose_vector_actions", p)
    krylov = np.sum(source, axis=1)
    if np.linalg.norm(krylov) < 1e-14:
        krylov = np.sum(state["j"], axis=1)
    sequences = {"fourier": iter(fourier[nf:]), "receiver": iter(receiver[:, nr:].T),
                 "random": None, "krylov": None}
    families = cfg.get("pool_families", ("fourier", "receiver", "krylov", "random"))
    groups = []
    for group in range(q):
        family = families[group % len(families)]
        collected = np.empty((n, 0), complex)
        fallback_draws = 0
        for attempt in range(max(12, 4 * k)):
            if collected.shape[1] == k:
                break
            if family == "random":
                atom = rng.normal(size=n) + 1j * rng.normal(size=n)
            elif family == "krylov":
                krylov = model.G @ krylov
                if cost:
                    cost.add("green_vector_actions")
                atom = krylov
            else:
                try:
                    atom = next(sequences[family])
                except StopIteration:
                    atom = rng.normal(size=n) + 1j * rng.normal(size=n)
                    fallback_draws += 1
            candidate = candidate_orth(atom, np.column_stack((core, collected)), 1)
            if candidate.shape[1]:
                collected = np.column_stack((collected, candidate))
        if collected.shape[1] != k:
            raise ValueError("Requested current group capacity exceeds available quotient rank")
        groups.append({"id": f"{family}_{group}", "family": family,
                       "spatial": collected, "modes": spatial_modes(collected, p), "real_dof": 2 * k * p,
                       "fallback_draws": fallback_draws,
                       "origin": "seeded_random_fallback" if fallback_draws else family})
    removable_spatial = candidate_orth(np.column_stack(fourier[nf:nf + max(4 * k, k)]), core, k)
    if removable_spatial.shape[1] != k:
        raise ValueError("No full-rank removable current group")
    # Exact finite-space data representability audit, before any material fit.
    # Each source has independent complex coefficients, hence the same complex
    # range S U is projected source by source. This is a raw Frobenius/Y tail.
    residual = np.asarray(state["Y"]) - Y
    data_norm = max(float(np.linalg.norm(Y)), 1e-300)
    S_core = model.S @ core
    def receiver_tail(SU):
        left, singular, _ = linalg.svd(SU, full_matrices=False, check_finite=False)
        threshold = np.finfo(float).eps * max(SU.shape) * float(singular.max(initial=0.0))
        rank = int(np.count_nonzero(singular > threshold))
        Qs = left[:, :rank]
        tail = residual - Qs @ (Qs.conj().T @ residual)
        return rank, float(np.linalg.norm(tail) / data_norm)
    core_data_rank, core_tail = receiver_tail(S_core)
    core_real_dof = 2 * p * core.shape[1]
    for group in groups:
        rank, tail = receiver_tail(np.column_stack((S_core, model.S @ group["spatial"])))
        group.update(receiver_data_rank=rank, receiver_tail_relative=tail,
                     backbone_real_dof=core_real_dof,
                     active_real_dof=core_real_dof + group["real_dof"])
    receiver_audit = {"receiver_mode": "observable" if observable else "fixed_integer",
                      "receiver_relative_cutoff": receiver_rtol if observable else None,
                      "receiver_atoms": nr, "fourier_atoms": nf,
                      "backbone_spatial_rank": core.shape[1], "backbone_real_dof": core_real_dof,
                      "active_real_dof": core_real_dof + 2 * k * p,
                      "core_data_rank": core_data_rank, "core_receiver_tail_relative": core_tail,
                      "best_candidate_receiver_tail_relative": min((g["receiver_tail_relative"] for g in groups), default=core_tail),
                      "candidate_receiver_tails": {g["id"]: g["receiver_tail_relative"] for g in groups},
                      "candidate_origins": {g["id"]: g["origin"] for g in groups},
                      "tail_metric": "unwhitened_Frobenius_divided_by_norm_Y",
                      "tail_numerical_rank_relative_threshold": "eps*max(SU.shape)"}
    if cost:
        cost.add("dictionary_builds")
        cost.add("receiver_svd")
        cost.add("fourier_atoms_generated", n)
        cost.add("dictionary_real_dof", sum(g["real_dof"] for g in groups))
        cost.add("dictionary_backbone_real_dof", core_real_dof)
        cost.add("receiver_vector_actions", core.shape[1] + q * k)
        cost.add("receiver_tail_svd", q + 1)
        cost.add("receiver_tail_audit", **receiver_audit)
    return {"core": spatial_modes(core, p), "core_spatial": core,
            "removable": spatial_modes(removable_spatial, p),
            "groups": groups, "source_count": p, "group_real_dof": 2 * k * p,
            "receiver_singular_values": receiver_singular, "receiver_audit": receiver_audit}


def paid_physical_jvp(model, m, h, state, config, cost=None):
    if cost:
        cost.check(extra_rhs=model.E.shape[1])
        cost.add("physical_jvp_calls")
        cost.add("expected_complex_rhs", model.E.shape[1])
    if hasattr(model, "tangent"):
        tangent = model.tangent(m, h)[0]
    else:
        rhs = np.asarray(h)[:, None] * state["Q"]
        if state.get("lu") is not None:
            tangent = linalg.lu_solve(state["lu"], rhs, check_finite=False)
        else:
            tangent = linalg.solve(np.eye(model.n) - m[:, None] * model.G, rhs, check_finite=False)
            if cost:
                cost.add("expected_lu")
        if hasattr(model, "cost"):
            model.cost["actual_complex_RHS"] += model.E.shape[1]
            model.cost["tangent_RHS"] += model.E.shape[1]
    if cost:
        cost.add("receiver_vector_actions", model.E.shape[1])
    return whiten_data(model.pack(model.S @ tangent), config)


def evaluate_modes(model, Y, m, state, core, groups, config=None, cost=None, old_extra=None):
    cfg = dict(config or {})
    joint = JointCurrentModel(model, Y, cfg, cost)
    lin = joint.linearize(m, state["j"], core)
    prof = profile_schur(lin["b"], lin["B"], lin["A"], lin["Lambda"], lin["ell"],
                         cfg.get("lm", 1e-4), m, cfg.get("box", (.02, 20.0)), cost)
    baseline = None
    if old_extra is not None:
        baseline = release_candidate(prof, joint.current_matrix(m, old_extra), release="hard", cost=cost)
        old_p = baseline["p"]
        old_action = current_action(core, baseline["c_U"]) + current_action(old_extra, baseline["c_C"])
    else:
        old_p, old_action = prof["p"], current_action(core, prof["c"])
    _, ellF, LambdaF = regularizer(model, m, cfg)
    rF = whiten_data(model.pack(state["Y"] - Y), cfg)
    Jprovided = cfg.get("physical_J")
    def proposal_jvp(h):
        if Jprovided is not None:
            return np.asarray(Jprovided) @ h
        # Public frozen-anchor Born map is a proposal model, with no error bound.
        if cost:
            cost.add("receiver_vector_actions", model.E.shape[1])
            cost.add("born_proposal_actions")
        return whiten_data(model.pack(model.S @ (h[:, None] * state["Q"])), cfg)
    Jp0 = proposal_jvp(old_p)
    actions = []
    for group in groups:
        C = group["modes"]
        A_C = joint.current_matrix(m, C, lin["w"])
        rel = release_candidate(prof, A_C, cfg.get("release", "soft"), cfg.get("eta_target", .1), cfg.get("gamma"), cost)
        dp = rel["p"] - old_p
        actual = current_action(core, rel["c_U"]) + current_action(C, rel["c_C"]) - old_action
        normal = normal_diagnostic(model.G, m, state["Q"], actual, cfg.get("beta", 0.0), cost=cost)
        signature = quotient_normal_signature(model.G, m, state["Q"], core, C, cost=cost)
        prescore = physical_task_gain(rF, Jp0, proposal_jvp(dp), old_p, dp, ellF, LambdaF)
        spatial = group.get("spatial")
        energy = float(np.linalg.norm(spatial.conj().T @ state["j"]) ** 2) if spatial is not None else float(np.linalg.norm(C) ** 2)
        actions.append({"group": group, "release": rel, "delta_p": dp, "old_p": old_p,
                        "current_action": actual, "normal": normal, "signature": signature,
                        "proposal_gain": prescore, "proposal_model": "provided_exact_J" if Jprovided is not None else "Born_no_error_bound",
                        "energy_score": energy, "physical_gain": None})
    selector = cfg.get("selector", "material_step")
    if selector in ("material_step", "task", "schur"):
        ordered = sorted(actions, key=lambda a: a["proposal_gain"], reverse=True)
    elif selector == "energy":
        ordered = sorted(actions, key=lambda a: a["energy_score"], reverse=True)
    elif selector == "normal":
        ordered = sorted(actions, key=lambda a: a["normal"]["normal_energy"], reverse=True)
    elif selector == "random":
        ordered = [actions[i] for i in np.random.default_rng(int(cfg.get("random_seed", 20261101))).permutation(len(actions))]
    elif selector in ("fourier", "krylov", "receiver"):
        # Fixed native-family control, retaining original public pool order.
        # Every pool group above was still acquired, linearized and costed.
        ordered = sorted(actions, key=lambda a: a["group"]["family"] != selector)
    else:
        raise ValueError(f"Unknown current selector: {selector}")
    ordered = [a for a in ordered if not a["release"]["duplicate"]]
    finalists = ordered[:int(cfg.get("finalist_jvps", 2))]
    if finalists:
        # Old-step action is cached once; each finalist pays p more tangent RHS.
        Jp = paid_physical_jvp(model, m, old_p, state, cfg, cost)
        for action in finalists:
            Jdp = paid_physical_jvp(model, m, action["delta_p"], state, cfg, cost)
            action["physical_gain"] = physical_task_gain(rF, Jp, Jdp, old_p, action["delta_p"], ellF, LambdaF)
        if selector in ("material_step", "task", "schur"):
            finalists.sort(key=lambda a: a["physical_gain"], reverse=True)
    selected = finalists[0] if finalists else None
    return {"profile": prof, "baseline_release": baseline, "old_p": old_p,
            "old_current_action": old_action, "actions": actions, "finalists": finalists,
            "selected": selected, "linearization": lin}


select_modes = evaluate_modes
