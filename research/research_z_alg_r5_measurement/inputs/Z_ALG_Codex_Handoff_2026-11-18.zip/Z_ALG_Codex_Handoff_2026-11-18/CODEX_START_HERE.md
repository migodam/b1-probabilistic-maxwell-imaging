# Codex initial assignment -- do NOT skip audit

You have received a research handoff ZIP for the Z-ALG project in `b1-probabilistic-maxwell-imaging`.

## Research question

For a **known penetrable host with 4-6 actual independent real material DOFs**, can we enumerate and verify distinct roots of a full nonlinear scalar-TM VIE, then choose ONE **physically accessible** additional illumination with a certified practical separation margin? If yes, does this save measured excitations / total scientific cost compared with completing the source basis and direct inversion, and compared with homotopy + the same illumination rule?

This is NOT a project to improve 576-pixel digit reconstructions using a tree. Do not introduce neural scoring.

## Sequence

1. Read `AGENTS.md`, the PDF, `docs/02_math_contract.md`, and `tasks/GATE_0_repo_audit.md`.
2. Inspect actual repo code and machine results at recorded commit; write `PROVENANCE_AUDIT.md` with confirmed paths, Git commit, and any disagreements with this handoff. Compare `GENERAL6_00` archived results without overwriting them.
3. Propose a minimal, isolated implementation layout that reuses the archived nonlinear forward solver and physical acceptance routine. Identify mathematical assumptions for each function.
4. Implement Gate-1 tests for `w(t,c)`, `h_b(t,c)` and physically generated `Bplus` and a frozen small source menu.
5. Prove numerically to stringent tolerances (and analytically in docs) that `b=B a` gives `N b=0` and identical new-source predictions for all exact old-data roots; ensure the new source does NOT silently lie in old span.
6. For each archived valid 6-material root, compare dual-source prediction with independent full VIE simulation under the proposed source, logging errors and condition numbers.
7. Compute all pairwise whitened differences, realizability and noise/model-error margins; return `DISAMBIGUATED`, `AMBIGUOUS`, or `UNKNOWN` correctly.
8. Include the alternative `B_full` full-rank direct inversion and rank/conditioning test. Compare equivalent noise and forward-model assumptions.
9. Run only the previously frozen 4-6 material trial count and budget. Add strong homotopy, multistart TRF, reciprocal TRF, random/fixed illumination controls with equivalent full cost and shared cache where applicable.
10. Deliver compact `RESULTS.md`, `cost_ledger.csv`, `candidates.csv`, `decision_trace.json`, and explicit decision: GO / NO-GO / UNKNOWN. Report the complete list of failures.

## Gate-1 acceptance

- Reproduces exact algebraic identities on tests, including old-source no-new-information theorem.
- Every accepted material passed full nonlinear Maxwell forward validation and physically meaningful material checks.
- For all candidates, covers root/path status, realness, box, pole/node and duplicate criteria.
- Distinguishes conditional finite-root exhaustiveness from *global noise-ball* exhaustiveness.
- No selection uses GT; only post-hoc audit may evaluate ground-truth error.
- New-source fields are realizable with declared antenna/source geometry and energy budget.
- A successful measurement is not merely a nonzero response difference: it meets stated noise and model-error thresholds.
- Compares the proposed one-measurement rule against source-basis completion and equivalent existing solvers.
- Records compute and measurement costs for successful/failed branches alike.
- If any required certificate or model assumption fails, state `UNKNOWN`; do not convert failure into a claimed recovery success.

## Hard stopping

See `contracts/experiment_plan.json` for source-menu, root, RAM, CPU, and high-precision limits. Do not start Gate 2, even if Gate 1 succeeds, without a user direction. You may halt with a falsifying negative result; that is valuable.

## Deliver first, before writing ambitious code

A 1-2 page plan showing (a) exact files to reuse, (b) observed evidence versus assumptions, (c) how physically admissible Bplus is constructed, (d) frozen baselines, (e) failure conditions, and (f) estimated source-count/computation ledger. Then implement the smallest verified patch.
