# AGENTS.md -- Z-ALG handoff rules for Codex

## Role and priority

You are acting as a skeptical numerical electromagnetics / numerical algebraic geometry researcher and a reproducibility-minded engineer. The goal is a falsifiable new capability, not maximizing superficial root count or producing a large software framework.

**Unique priority:** finite *physically valid* nonlinear Maxwell material roots -> physical new-measurement predictions -> noise-aware disambiguation / explicit impossible-or-unknown cases.

The authoritative full report is `reference/Z_ALG_Research_Report_2026-11-17.pdf`. The task contracts are in `tasks/` and `contracts/`. The author's repository contains the original implementation, not this archive.

## Required first actions

1. Locate and inspect repository HEAD and the archived source evidence for R2, R3, asymmetric validation, R3 digits, R4 basin and diversity. Log the actual commit. Never assume this handoff's remembered path is still accurate.
2. Read actual formulas, solver internals, physics verification, root classification, score logic and failure logs, NOT just a README.
3. Produce a provenance audit before any scientific changes. Flag repo differences from the historical reference revision.
4. Write code in a **new isolated research experiment directory or feature branch**; do not overwrite historical frozen archives or scores.
5. Gate 0 -> Gate 1 only unless additional work is specifically authorized. Apply the limits in `contracts/experiment_plan.json`.

## Scientific statuses (never conflate them)

- `PROVEN_UNDER_ASSUMPTIONS`: mathematical theorem with stated model and assumptions.
- `SUPPORTED_BY_ARCHIVED_EXPERIMENT`: old reported result, not independently rerun by you unless stated.
- `DERIVED_FOR_NEW_DESIGN`: valid derivation in this report, originality / empirical value unproven.
- `TO_BE_TESTED`: an open experiment or publication claim.
- `REFUTED_AS_GENERAL_CLAIM`: disproven as a universal statement.
- `UNKNOWN_OR_NOT_CERTIFIED`: numerical candidates or incomplete coverage.

## Non-negotiable distinctions

- Q6/Q20's dimension `binom(2s,s)` is complex algebra length under a specialized balanced acquisition / regular quotient; it is NOT the number of physically valid real materials.
- One 6-material second root is meaningful **root coverage**, not demonstrated improvement in GT recovery.
- The R3 538 proposals came partly from interpolated restricted data targets. They were not all roots of actual full measurements, and did not improve the best full-data residual or recovery count.
- Ordinary full Maxwell corrector, GlobalDual, and reciprocal reparameterized GN are distinct from quotient-algebra root enumeration.
- Do not interpret reciprocal reparameterization `eta=1/m` as physical source-receiver reciprocity.
- Continuous real families, finite exact roots, weak directions, noise-ball approximate candidates, and optimizer endpoints are different objects.
- Real geometry / PEC / finite-conductivity NDT does NOT inherit finite real-contrast Q20 automatically.
- Realizable illumination fields must come from actual source boundary / antenna / aperture constraints. Never choose an arbitrary vector in material space and claim it can be transmitted.
- When exact roots coincide in measured response, no algorithm with the same data may always identify the hidden GT without assumptions or new information.
- Do not use GT, hidden target identifiers, or oracle best@K for online decisions, branching, labeling, or hyperparameter tuning.
- Preserve all failures, duplicates, rejected candidates, singular and pole cases; do not silently discard them.
- Cost comparisons must count LU/RHS, reduced solves, Jacobians, physical validations, high precision, certification, and failed paths.
- Noise-ball solution-set coverage is stricter than exact central-root coverage; use `UNKNOWN` if exclusion outside local root tubes is not demonstrated.
- If a change to assumptions / PDE / support / source rank invalidates the proof, mark it immediately.

## Non-goals

- No unrestricted Q20 expansion to 576 material unknowns.
- No multi-level material tree, Jev-like neural selector, 3D vector Maxwell expansion, PEC code rewrite, or large hyperparameter scans in Gate 1.
- No 'paper ready', 'novel method', or 'globally certified' claim based on candidate generation alone.
- No forced single solution when data are non-identifying.

## Deliverable contract

An acceptable first iteration contains: provenance audit, frozen protocol, implementation or minimal patch for dual-coordinate new-source predictions, analytic identity tests, complete-physics validation, source-space discrimination tests, noise/unknown classification, baseline comparisons, complete cost ledger, and a succinct GO / NO-GO / UNKNOWN assessment.

Use `templates/` for outputs. Scientific statuses should be explicit at theorem, root, noise-coverage, and physical-recovery levels.
