# Z-ALG Gate-1 results -- TEMPLATE, NO RESULTS FILLED

## Provenance

- Repository URL / commit:
- Branch / new experiment directory:
- Run date, hardware, software, float precision:
- Frozen protocol SHA / attached file:
- Archived baseline reproduced? (yes/no/partial, link):

## Mathematical validity

- Exact VIE discretization and field convention:
- 2s active coordinate count and physical meaning:
- B rank, T condition, pole/node status:
- Old-span identity pass/fail and numeric tolerance:
- New-source dual/full independent VIE agreement:
- Certificates: isolated roots / exhaustive finite system / local tubes / global feasible set / UNKNOWN:

## Frozen measurement design

- Old and new actual source configuration:
- Receiver, frequency, polarization, power budget:
- Source-menu fingerprint, GT quarantining:
- Noise covariance, model discrepancy and feasible-set radius:
- Chosen decision metric and thresholds:

## Results table

| target_id | generator | physical roots | certified roots | unresolved | min sep. margin | source feasible? | unique branch? | post-hoc GT metric | total CPU | peak RAM |
|---|---|---:|---:|---:|---:|---|---|---|---:|---:|
| ... | ... | | | | | | | | | |

## Comparison

- Q vs homotopy root coverage:
- Q vs 64-start material & reciprocal TRF:
- Physical one-source discrimination vs fixed/random/optimal pair:
- One-source branch selection vs completing source basis direct inversion:
- Measurement count, energy, conditioning, cost, error:

## All negative evidence

- Missed, duplicated, domain-invalid, complex, poles, unresolved paths:
- Unseparated valid pairs, insufficient SNR, host mismatch:
- Wrong-complement / conditional-subdata failure:
- Any deviations from frozen protocol (if present, mark exploratory, not primary):

## Decision

- GO / NO-GO / UNKNOWN:
- Justification from independent measurements, not root count alone:
- Coverage scope statement:
- Next smallest falsifiable scientific question:
