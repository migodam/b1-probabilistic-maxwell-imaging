# Source audit -- TEMPLATE

- Repo HEAD:
- Archive reference SHA: `55724cb1a7bafbd9afa3b95ac817522f8dcaf2d0`
- Changes since archive:
- Audit timestamp and environment:

| Claim / hypothesis | Actual file:function/lines | Code revision | Physics assumptions | Proof status | Archived result ref | Reproduced? | Disagreement / open question |
|---|---|---|---|---|---|---|---|
| Full model and reduced VIE | | | | | | | |
| Dual chart and Q20 | | | | | | | |
| Root verifier | | | | | | | |
| R3 local proposals | | | | | | | |
| Material GN / reciprocal | | | | | | | |
| GlobalDual attribution | | | | | | | |
| Realizable source API | | | | | | | |

## Read-only audit checklist

- [ ] Inspected source beyond README.
- [ ] Confirmed exact old-data vs interpolated target labels.
- [ ] Distinguished true second material root from GT recovery.
- [ ] Confirmed candidate verifier is complete original Maxwell forward.
- [ ] Inspected all records and the real reproducibility status.
- [ ] Identified write isolation; original archives untouched.
