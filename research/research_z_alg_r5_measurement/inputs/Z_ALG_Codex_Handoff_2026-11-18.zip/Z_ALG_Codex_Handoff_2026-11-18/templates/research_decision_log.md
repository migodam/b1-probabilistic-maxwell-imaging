# Decisions, changes, and falsification log

| timestamp | stage | hypothesis | frozen decision / threshold | evidence before decision | new observation | status | cost | follow-up authorization |
|---|---|---|---|---|---|---|---:|---|
| ... | ... | ... | ... | ... | ... | ... | ... | ... |

## Scientific claims audited

- [ ] Every PROVEN label has explicit assumptions and a demonstration.
- [ ] Every archived experiment label is distinguished from a new rerun.
- [ ] Every hypothesis failing in data is retained and reported.
- [ ] Coverage claims distinguish exact central roots and global noisy feasible sets.
- [ ] Full forward physics and source feasibility are checked independently.
- [ ] GT not used in any online decision.
