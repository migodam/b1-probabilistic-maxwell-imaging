# Z-ALG / Maxwell inverse scattering -- Codex research handoff

Date of package: 2026-11-18 (Asia/Singapore).
Scope: decision, derivation, implementation contract, and small falsifiable tests. This is a handoff, NOT a completed implementation or new experimental result.

## START HERE

1. Read `AGENTS.md` (rules and non-goals).
2. Read `CODEX_START_HERE.md` (the exact first task to execute).
3. Read `reference/Z_ALG_Research_Report_2026-11-17.pdf` (19-page Chinese research report, authoritative source).
4. Read `docs/01_decision_and_evidence.md` and `docs/02_math_contract.md`.
5. Inspect the user's checkout of https://github.com/migodam/b1-probabilistic-maxwell-imaging at or after recorded revision `55724cb1a7bafbd9afa3b95ac817522f8dcaf2d0`.
6. Implement **Gate 0 / Gate 1 only** with tests and cost logs, not a new branch tree or a high-dimensional sweep.

## Primary recommendation

Build a *physically realizable finite-root ambiguity / measurement-completion diagnostic* for a known penetrable host with 4-6 actual independent real material unknowns, one complex receive channel, and full nonlinear VIE physics.

The key formula at fixed frequency, receive row, and known host is

`h_b(c) = w_0 b + c N b`, for source-induced host field `b` on the active support.

The model must compare a one-extra-measurement branch-disambiguation strategy against simply completing the source basis and directly recovering `w` and material `z`. More roots alone, low data residual alone, and oracle-best@K alone are NOT wins.

## Package layout

- `AGENTS.md`: local instructions for Codex when unzipped into a working directory.
- `CODEX_START_HERE.md`: ready-to-run initial assignment / milestone deliverables.
- `docs/01_decision_and_evidence.md`: established results, failed claims, target ranking, and uncertainty.
- `docs/02_math_contract.md`: physics, exact reduction, dual chart, root coverage, discrimination, stability and caveats.
- `docs/03_architecture_and_cost.md`: comparison with GN-first, tree, homotopy, costs and pseudocode.
- `docs/04_candidate_selection_and_measurement.md`: validation, candidate equivalence, noise, risk, decisions.
- `docs/05_novelty_and_papers.md`: prior art, originality boundary, and publication target assessment.
- `docs/06_repo_audit_map.md`: paths to inspect; these are references, not code embedded in this archive.
- `tasks/GATE_0_repo_audit.md`: read-only validation of repo and provenance.
- `tasks/GATE_1_six_material.md`: smallest useful coding/experiment milestone.
- `tasks/GATE_2_structure_and_failure.md`: conditional 12-48-state test, not a default action.
- `contracts/experiment_plan.json`: machine-readable frozen budget and gates.
- `contracts/record_schema.json`: machine-readable scientific result schema.
- `templates/*`: reporting templates without fabricated success numbers.
- `reference/*`: intact 19-page Chinese PDF and plain-text extract.
- `tools/verify_package.py`: checks integrity and JSON syntactic validity.

## What this package does NOT contain

- No clone of the user's GitHub repo and no alteration to that repo.
- No new material-root computations, certificates, measured data, or benchmark outcomes.
- No network dependencies; all scientific references are URLs and titles for Codex to verify.
- The text extract is a convenience; use the PDF for math, figures, tables and authoritative wording.

## Start Codex

Upload this ZIP as reference context, or unpack it next to the repository. Give Codex this instruction:

> Follow `AGENTS.md` and `CODEX_START_HERE.md` in this handoff. First audit existing Z-ALG implementation; then implement a strictly bounded Gate-1 physical illumination ambiguity test. Preserve previous frozen results. Do not conduct a parameter sweep or claim improved recovery without completed end-to-end evidence.

