# 04 -- Candidate validation, ranking, risk and uncertainty

## Candidate classification layers

Every candidate MUST separately record:

1. `material_admissibility`: sufficiently real, within true material box, positive permittivity / passivity as relevant, topology and support physically allowable.
2. `forward_state_validity`: invertibility/resolvent pole margin, original state equation residual, constitutive residual, discretization and physical solution conditioning.
3. `full_data_compatibility`: complete nonlinear Maxwell forward prediction, all illuminations and receivers, whitened error with full noise covariance and declared model discrepancy.
4. `root_or_set_certificate`: an approximate root, isolated interval-certified root, exhaustive exact finite-root system, local feasible-set tube, or global feasible-set cover. Distinct fields.

A quotient root of an interpolated restricted system may be materially legal but not old-data compatible; it is a proposal, not a recovered full-data alternative.

## Deduplication: THREE independent metrics

- Material-space separation (after physically justified normalization): numerical duplication vs actually different material distributions.
- Geometry / topology: hole count, connectivity, shape class and support; should not be assumed available in the 4-6 fixed-state model.
- Predicted measurable response: Mahalanobis-like whitened separation, possibly 0 for materially different roots.

Do NOT define global equivalence classes via single-link threshold chaining: closeness under epsilon need not be transitive. A pairwise graph is acceptable if labeled as a compatibility graph, not a true equivalence relation.

## Online selection and abstention

- Use hard physical admissibility and complete data compatibility FIRST.
- Preserve more than one hypothesis if old data cannot distinguish them.
- A smaller residual among statistically indistinguishable roots cannot be declared 'truer'.
- If model assumptions differ, compare within explicit priors/model evidence, not by raw least-squares values.
- MAP density is not the same as posterior branch mass. Local curvature and continuous-fiber volume matter.
- An optimization basin hit frequency is not a Bayesian posterior probability.
- If all valid roots are distinguishable under extra measurements, use the physical source selection rule and retain all branches still noise-compatible after acquisition.
- If no available new measurement yields an adequate separation, output MULTIPLE_COMPATIBLE or UNKNOWN instead of choosing a hidden GT proxy.

## Detection task instead of unique imaging

For a safety-relevant property R(m) (e.g., dangerous crack), the honest target is the robust range over the FULL feasible set F:

`R_min = inf_{m in F} R(m), R_max = sup_{m in F} R(m)`.

A range computed only over found roots is merely an INNER sampled range. It cannot rule out unenumerated dangerous material models. Strong safety statements require full feasibility-set coverage or an independent certified global bound.

## Root-tube measurement margins

For candidate tube j and source q, calculate a whitened prediction region, and upper bound it by a ball centered at mu_j with radius rho_j. New measurement noise radius tau_new. A sufficient pairwise nonintersection test is

`||Sigma_new^(-1/2) (mu_i-mu_j)|| > rho_i+rho_j+2*tau_new`.

Record whether the covariance is diagonal, full, complex proper, pseudo-covariance present, correlated across illuminations, or empirical. Use compatible real vectorization as required; do not silently assume iid Gaussian noise.

Separate **measurably different means** from **certifiably disjoint feasible prediction sets**. If exact roots were only found but global noise-ball coverage was not, report 'separated found candidates' and NOT 'all physically possible materials separated'.

## No Jev-like decision model at this stage

With at most D=20 complex conditional roots in the initial 6-material chart, physical tests and predictions are cheaper, more interpretable, and less likely to leak labels than training a neural selector. A model is not justified until a measured candidate-scheduling bottleneck exists.

Only after Gate 1 demonstrates that bottleneck, compare physics-only frozen rules to random scheduling and simple logistic regression / shallow tree using VALID online features: noise-whitened residual, conditioning, pole/node margin, short-refinement improvement, diversity and computational cost. Train labels from fixed additional computation budget and physically verified outcomes, NOT GT correctness labels used for online inference. Split by whole targets/host/contrast/grid families; calibrate and allow abstention. Include label generation and mis-pruning cost. Do not present the output as 'probability of unique GT'.

## Key statistical negative statement

If F_old(m1)=F_old(m2) and both use the same likelihood/noise model, no estimator based ONLY on old data can always identify m1 over m2. Additional prior information, new observation, or a restrictively justified model is necessary. An algorithm cannot evade this by stronger optimization.
