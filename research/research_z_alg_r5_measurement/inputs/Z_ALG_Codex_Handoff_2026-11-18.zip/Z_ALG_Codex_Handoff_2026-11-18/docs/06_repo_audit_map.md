# 06 -- Repository and literature audit map

Repository: https://github.com/migodam/b1-probabilistic-maxwell-imaging
Historical checked reference commit (from report): `55724cb1a7bafbd9afa3b95ac817522f8dcaf2d0`, dated 2026-11-16. This handoff does NOT claim the user's present checkout is at that SHA.

## High priority files -- verify exact paths at actual checkout

### Asymmetric six-material real family

- `research/research_z_alg_asymmetric_validation/MATHEMATICAL_PROOFS.md`
- Corresponding archived validator and exact-binary64 operator inputs (locate actual filenames)
- Inspect continuation chart, forward physics residual, real material ranges, absence of swap symmetry and exact scope of certificate.

### R2 quotient / new valid root

- `research/research_z_alg_r2/theory/general_quotient.md`
- `research/research_z_alg_r2/theory/algebraic_structure.md`
- `research/research_z_alg_r2/theory/branches_and_field.md`
- `research/research_z_alg_r2/src/general_quotient_solver.py`
- `research/research_z_alg_r2/experiments/run_six_material_holdout.py`
- `research/research_z_alg_r2/COST_LEDGER.md`
- `research/research_z_alg_r2/MATHEMATICAL_THEORY.md`
- `research/research_z_alg_r2/FORMULA_COMPENDIUM.md`
- `research/research_z_alg_r2/REPRODUCE.md`
- In raw machine result inspect valid roots, full nonlinear residual, material RMS, realness, box, other branches, and `NOT_RIGOROUSLY_CERTIFIED` status.

### R3 12-material / local proposal failure

- `research/research_z_alg_r3/src/solver.py`
- `research/research_z_alg_r3/src/physics.py`
- `research/research_z_alg_r3/MATHEMATICAL_THEORY.md`
- `research/research_z_alg_r3/audit/MECHANISM_AND_IMPLEMENTATION.md`
- `research/research_z_alg_r3/experiments/validate_predictions.py`
- Inspect target interpolation tau, local support, fixed complement, candidate acceptance, full-data residual and final benchmark count.

### Digits and R4

- `research/research_z_alg_r3_digits/RESEARCH_REPORT_ZH.md`
- `research/research_z_alg_r4_basin/MATHEMATICAL_THEORY.md`
- `research/research_z_alg_r4_basin/RESEARCH_REPORT_ZH.md`
- `research/research_z_alg_r4_diversity/SCIENTIFIC_DECISION.json`
- `research/research_z_alg_r4_diversity/src/solver.py`
- `research/research_z_alg_r4_diversity/score_results.py`
- `research/research_z_alg_r4_diversity/RESEARCH_REPORT_ZH.md`
- Do NOT credit GlobalDual improvements to quotient enumeration.

## Foundational / comparison works (DOI or canonical URL)

- Vasco (2000), An algebraic formulation of geophysical inverse problems, DOI `10.1046/j.1365-246x.2000.00188.x`.
- Everett (1996), Homotopy, Polynomial Equations, Gross Boundary Data, and Small Helmholtz Systems, DOI `10.1006/jcph.1996.0070`.
- Everett (2026), Multiple solutions to geophysical inverse problems via tracking flights across a deeply incised model landscape; online 2026-10-09, DOI `10.1093/gji/ggag432`.
- Bouchet et al. (2021), Optimal Control of Coherent Light Scattering for Binary Decision Problems, DOI `10.1103/PhysRevLett.127.253902`.
- Bouchet et al. (2021), Maximum information states for coherent scattering measurements, DOI `10.1038/s41567-020-01137-4`.
- Wu et al. (2022), Bayesian experimental design with projected neural networks, arXiv `2201.07925`.
- Sommese, Verschelde, Wampler (2001), Numerical decomposition of polynomial system solution sets, DOI `10.1137/S0036142900372549`.
- Duff et al. (2019), Homotopy continuation and monodromy, DOI `10.1093/imanum/dry017`.
- Hauenstein, Sottile (2012), alphaCertified, DOI `10.1145/2331130.2331136`; Breiding et al. interval root certification, arXiv `2011.05000`.
- van den Berg, Kleinman (1997), CSI, DOI `10.1088/0266-5611/13/6/013`.
- Zhong, Chen (2009), TSOM, DOI `10.1088/0266-5611/25/8/085003`.
- Zhong, Xu (2019), CIE in 3D inverse EM scattering, DOI `10.3390/jimaging5020027`.
- Golub, Pereyra (1973), variable projection, DOI `10.1137/0710036`; van Leeuwen, Yang (2025), constraint relaxation, DOI `10.1088/1361-6420/adab89`.
- Chai, Moscoso, Papanicolaou (2014), strong localized scatterers, DOI `10.1137/130943200`.
- Cakoni, Harris (2015), defective region in anisotropic material, DOI `10.1088/0266-5611/31/2/025002`.
- Ammari, Chow, Zou (2015), high-contrast scattering coefficients and super-resolution; see full PDF references.
- Xudong Chen (2018), PEC reconstruction, DOI `10.1002/9781119311997.ch7`.
- Sun et al. (2020), Field-Only Surface Integral Equations for PEC, DOI `10.1364/JOSAA.378665`.
- NASA TM-2020-5006765 Vol. II Appendix K (metal skin depth): https://ntrs.nasa.gov/api/citations/20205006770/downloads/20205006765_vol%20II.pdf
- TypeSafe AI (2026), Jev and system-one models: https://typesafe.ai/blog/introducing-system-one-models-and-jev
- Guo et al. (2017), Calibration of Modern Neural Networks: https://proceedings.mlr.press/v70/guo17a.html

## Required provenance table

After inspecting source code, return a table:
`hypothesis | exact file:function | source revision | physics/model assumptions | mathematical proof status | archived result? | reproduced? | uncertainty / gap`.

No README-only audit is accepted. Use lines or GitHub permalinks in the actual Codex output; this archive supplies bibliographic paths but no line-level verification.
