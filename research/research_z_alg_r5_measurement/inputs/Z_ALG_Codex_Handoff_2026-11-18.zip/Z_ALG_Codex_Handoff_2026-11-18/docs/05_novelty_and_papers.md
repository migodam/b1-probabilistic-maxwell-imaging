# 05 -- Prior-art boundaries and publication positioning

## Do not claim the following as first-ever

- Algebraic electromagnetic / Helmholtz inversion, finding nonunique roots via homotopy, or exploring multiple inverse-model endpoints: earlier Everett 1996 / Vasco 2000; Everett 2026 specifically works on tracking flights from already found EM inverse solutions.
- Polynomial quotient multiplication matrices, determinantal ideals, Hilbert-Burch / Eagon-Northcott, witness sets, monodromy, homotopy, interval Krawczyk or alphaCertified root tests: established numerical algebraic geometry.
- Coupled field/current/material inversion, CSI/SOM/TSOM/CIE, variable projection, PDE constraint relaxation or strong GN/TRF baselines: established literature.
- Optimal illumination for discriminating two hypotheses: Bouchet et al. PRL 2021 and related coherent scattering information design work.
- Generic Bayesian design of multi-modal hypotheses: an established field.
- Low-dimensional scatterers or full nonlinear Foldy-Lax localization by itself: existing modeling and sparse/local optimization studies.

See `../docs/06_repo_audit_map.md` and `../reference/Z_ALG_Research_Report_2026-11-17.pdf` (last two pages) for references and qualification of full texts versus abstracts.

## Actual candidate novelty

An honest, narrower scientific contribution would combine:

1. A demonstrably complete / explicit-range root atlas for a physically meaningful finite nonlinear Maxwell model with stated balanced-acquisition and exclusion conditions;
2. the exact *realizability-constrained* affine measurement action on its Maxwell-specific dual quotient;
3. principled identification of invisible illumination directions and node/continuous-family limitations;
4. noise/model-error certified disambiguation (or demonstrable impossibility) using practical illumination; and
5. a measured / computational-cost study showing when it beats extra-source direct completion and strong homotopy/multistart baselines.

Simply showing `h_b = w0 b+cNb` is insufficient for a strong paper: Maxwell forward linearity in illumination and quotient algebra function evaluation are standard. Also, finite-dimensional 'generic hyperplane' arguments and norm-ball separation bounds are elementary. The science requires a nontrivial physical / algebraic applicability and meaningful quantitative gain.

## Candidate paper ranking

1. Main: **Certified ambiguity sets and measurement completion for nonlinear Maxwell scattering with finite material support** (working theme, not a publication-ready novelty claim). Best prospective fit: *Inverse Problems* / *SIAM Journal on Imaging Sciences*.
2. Backup: an independently valuable Maxwell real-branch atlas with explicit degeneracy and certified coverage conditions; only if stronger than generic numerical algebraic geometry, implicit function theorem, and ordinary root tracking.
3. Auxiliary: quotient multi-root initialization -> full GN/TRF; low novelty unless convincing new recovery wins against all budget-matched alternatives.

## Score estimates (research judgment, out of 10)

| Dimension | Archived status | Conditional if chain is proven and succeeds |
|---|---:|---:|
| Mathematical novelty | 4 | 6-7 |
| Physical novelty | 3 | 5-6 |
| True material recovery | 3 | 6 |
| Computational controllability | 6 on small models | 7 on genuine fixed supports |
| Application value | 4 | 7 |
| Experimental maturity | 4 | remains 4 until new validations are done |

| Venue | Current readiness | Conditional ceiling, NOT probability | Additional barrier |
|---|---:|---:|---|
| Strong IEEE TAP | 3 | 6 | realistic radiators/geometry, EM model discrepancy, independently validated physical or hardware experiment |
| Strong SIAM JIS | 4 | 7 | nontrivial computational method, complete cost/comparison, beyond a handful of illustrative micro-models |
| Strong Inverse Problems | 4 | 7 | mathematical completeness and stability, meaningful impossibility / identifiability under noise and model error |

These scores do not pre-approve novelty. Perform a specific current literature novelty audit before manuscript claims; the previous PDF examined work through 2026-11-17.

## Citation / source limitation

Original references cited in the full report have varying access levels. Some source claims were derived from abstract/publisher descriptions, not full paid content. Codex must separate inspected full-text claims from metadata-only claims and revisit direct precedence if preparing a manuscript. Do not fabricate quotations or fully-read claims.
