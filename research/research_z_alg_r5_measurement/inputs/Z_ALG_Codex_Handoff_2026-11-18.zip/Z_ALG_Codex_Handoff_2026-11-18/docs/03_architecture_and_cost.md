# 03 -- Architecture decision, physical cost and pseudocode

## Reject default material search tree

**A: quotient roots -> GN initialization.** Mathematically sensible for a genuinely low-dimensional compatible physical model; a root satisfying selected sub-measurements need not satisfy all data. In high-dimensional imaging the candidate support/geometry has to be supplied; otherwise there is no source of a globally relevant algebraic initial image. Must benchmark against Born, CSI, SOM, TRF, learned seeds and true multistart with equal full costs.

**B: GN -> quotient branching -> GN.** Can be used as a bounded diagnostic of a stalled high-residual GN state with independently justified active support. BUT R3 already tried restricted Q6 and subsequent full GN, and produced many candidates without actual success gain. Wrong fixed complement may exclude the correct image entirely, so no amount of local root enumeration fixes the model family. Do not declare a universal stagnation trigger.

**C: alternating quotient/GN tree.** Not a default scientific method. A finite complete quotient already contains all conditional roots. Repeating the same slice adds nothing; changing the support or slice changes the problem. A tree without certified coverage gain or a physical source of new information is an expensive form of beam search / multistart.

**D: finite certified root set -> accessible measurement design -> independent physics check -> joint refinement.** This is the unique proposed main architecture. GN/TRF are per-branch noise correctors, not a claim of algebraic global imaging.

## From one root to others: exact distinction

- No general material symmetry maps one real Maxwell root to all other roots. A polynomial field's monodromy action is not a physical group action preserving real materials and material bounds.
- If the quotient has been completely computed and its roots certified, 'one root to next root' only means reading existing quotient eigenstructure or using a known numerical algebraic geometry path method. Do not relabel those as original.
- Homotopy / parameter continuation may produce additional candidate endpoints when changing measurements, support, or problem parameters, but intermediary paths can be complex, cross poles, leave material box, or become singular. Endpoints require full independent verification.
- Witness sets address complex positive-dimensional algebraic components, not automatically all physically legal real connected components.
- Interval subdivision, Krawczyk and alphaCertified can certify isolated cases but may be expensive. Distinguish root existence/isolation from exhaustive complement exclusion.
- Root tracking on parameter loops without nontrivial monodromy simply returns to the initial root. A generic 'one real root generates a second real root' statement is false.

## Proposed minimal algorithm

```text
INPUT:
    m0, P, G, S, original source fields (physical), y_old
    material domain, noise covariances, forward/model error budgets
    bounded physical extra-source menu, power/geometry constraints
    hard computational & measurement budget

build A0 LU; form reduced U, H, B, R and source-specific background Y0
verify algebraic chart: A0 invertible, rank B=s, 2s active state coordinates,
                       nondegeneracy and numerical condition bounds
run or reuse archived Q6/Q20 isolated-root candidates
compare with independent homotopy and budget-matched TRF
for each candidate:
    check real material, box, passivity, node, pole & conditioning
    perform full nonlinear VIE physical forward check on all OLD data
    attach certificate status and failure provenance
cluster numeric duplicates without merging physically distinct roots
if complete exact-root coverage cannot be certified: mark UNPROVEN_COVERAGE
if noise coverage needed: build local certified tubes; if no complement
    exclusion, mark GLOBAL_NOISE_COVERAGE_UNKNOWN

build Bplus only from physically realized source excitations in known host
assert old source span b=B a implies N b=0 and no root discrimination
for each available physical b in fixed menu:
    independently check y_b from original physics for a sample of roots
    predict h_b(t,c) using dual coordinates and uncertainty propagation
    compute pairwise whitened separation & tube/noise margins
rank new sources by conservative worst-pair separation / total cost
if no source can meet threshold: return AMBIGUOUS or UNKNOWN (not success)

compare to directly completing B_full and inverting for w then z
select one source only if design is feasible and meaningful
if actual new y measured/simulated under frozen protocol:
    retain all tube/branch explanations consistent with it
    jointly refine each surviving branch by fixed-budget full GN/TRF
    output ONE_BRANCH, MULTIPLE_COMPATIBLE or UNDETERMINED
save full candidate registry, noise/coverage status, source budget, cost ledger
POST-HOC ONLY: evaluate GT error / topology recovery on held-out cases
```

No hidden GT may choose which root to extend, which source to pick, when to stop, or which branch is true.

## Source-selection rules

Start with a finite physical source menu, rather than solving a large continuous design problem. Include: genuine available single transmitters, a few fixed random coherent transmitter combinations, and 1-2 analytically designed pairwise-discrimination combinations if hardware supports complex amplitude/phase control.

For pair i,j:

`g_ij = (c_i-c_j) N Bplus`. With `a*P_energy a <= E`, and independent real/imag whitened noise standard deviation sigma,

`max_a |g_ij a|/sigma = sqrt(E)*||g_ij P_energy^(-1/2)|| / sigma`.

Use this as an *upper bound* for feasibility and a test for source-space impossibility. Worst-pair source design should evaluate full physical error margins, not only pairwise point distances.

## Mandatory reference comparator

After s extra independent sources, `Bfull=[B Bplus]` may be invertible, giving exact algebra-free `w = t_full Bfull^{-1}` and z readout. Include power, noise, conditioning, and acquisition overhead. If this simpler direct scheme wins at equivalent trust, the 'one-source Q20' architecture must be abandoned as a practical advantage (though finite ambiguity theory may survive).

## Quotient combinatorial budget

For k=2s, D=choose(2s,s). Storing s dense complex128 coordinate multiplication matrices alone takes `16*s*D^2` bytes; no factorization/workspace included.

| k | s | D | Approx. storage for s multiplication matrices |
|---:|---:|---:|---:|
| 4 | 2 | 6 | 1.2 KB |
| 6 | 3 | 20 | 19.2 KB |
| 8 | 4 | 70 | 0.31 MB |
| 12 | 6 | 924 | 82 MB |
| 16 | 8 | 12870 | 21.2 GB |
| 24 | 12 | 2704156 | 1.40 PB |

Dense eigenvalue extraction is typically cubic in D. The memory wall is NOT the only problem: coefficients, interval methods, eigenvector conditioning, and certified physical roots dominate at singular cases.

With n full unknown electromagnetic states, k active material coordinates, s old illuminations and L candidate new sources: base setup needs one large A0 LU plus roughly k+s+L RHS (implementation-dependent); dual prediction for K roots is roughly O(K*k*L), all-pairs comparison O(K^2*L). Full validation may use exact reduced-to-full reconstruction but count independent checks and all LU/RHS work consistently across methods.

## Budget fairness and stop semantics

- All root generators share physical forward model, ground-truth withholding, source fields, tolerances, source-menu and experimental domain.
- Report *separate* and *shared-cache* cost accounting where solver internals can reuse base LU.
- Count unsuccessful path tracking, failed certification, rejected nodes, high precision retries and source generation cost.
- A timeout or precision cap yields `UNKNOWN_OR_NOT_CERTIFIED`, not `NO_OTHER_ROOT`.
- Positive result requires physical root coverage, noise-aware source discrimination and at least one practically relevant measurement saving / diagnostic not matched by baselines.

See `../contracts/experiment_plan.json` for numbers and stage gates.
