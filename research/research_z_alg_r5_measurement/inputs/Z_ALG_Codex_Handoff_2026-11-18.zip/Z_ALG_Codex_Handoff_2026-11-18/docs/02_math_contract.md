# 02 -- Mathematical contract: physics, quotient, observability and proofs

All statements in this file refer to the finite-dimensional discretized scalar-TM nonlinear Maxwell VIE unless explicitly stated otherwise. Respect exact-discrete versus continuous-PDE and finite-precision versus interval-certified distinctions.

## 1. Exact full VIE / known-host reduction (ARCHIVED DERIVATION)

Definitions:

- `J = D_m (E_inc + G J)` with `A(m) = I - D_m G`;
- measured data `Y = S J`;
- `m = m0 + P z`, where `P` selects k ACTUAL material-state coordinates, not merely k shape parameters;
- `A0 = I - D_m0 G` invertible; `J0=A0^{-1}D_m0 E_inc`, `E0=E_inc+G J0`;
- `U=A0^{-1}P`, `H=P^T G U`, `B=P^T E0`, `R=S U`, `Y0=S J0`.

Then, exactly (within the discrete model),

```math
Y-Y_0 = R (I-D_z H)^{-1} D_z B, \
\det A(m) = \det A_0 \cdot \det(I-D_zH).
```

Derivation: subtract state equations, obtain `A0*(J-J0)=P D_z [P^T E0 + P^T G (J-J0)]`; substitute `J-J0=U*(I-D_z H)^(-1)*D_z B` for all sources. No Born approximation, all scattering orders retained.

This exact reduction ALREADY exists in R2. Do not claim it was discovered by the current experiment. Invertibility of `A0` is a chart requirement; if it holds, singularity of reduced resolvent is equivalent to singularity of full A(m) via determinant identity. The latter is not automatically an innocent coordinate singularity.

## 2. Dual quotient chart (ARCHIVED DERIVATION)

For one complex receive channel, `R` is 1xk. Under the archived balanced acquisition `k=2s`, `B` is 2s x s of rank s. Define a 1xk dual row and a 1xk compatibility row:

```math
w = R(I-D_zH)^{-1}D_z, \quad v=R+wH.
```

The data constraint is `wB=t`, `t=Y-Y0`. The constitutive constraint is `w_i=z_i v_i`.

Select a particular solution `w0` and left-null basis `N` (s x 2s):

```math
w = w_0 + cN, \qquad w_0 B=t, \quad NB=0, \quad c\in\mathbb C^{1\times s}.
```

For real material coordinates, each component satisfies `Im(w_i*conj(v_i))=0`, equivalently

```math
w_i \overline{v_i} - \overline{w_i} v_i = 0.
```

The archived derivation uses a complexified conjugate-compatible polynomial / determinantal system. Under precise genericity and invertibility assumptions, its quotient length is

```math
D=\binom{2s}{s}.
```

This D counts complex roots WITH multiplicities, not valid distinct real materials. A full quotient multiplication matrix contains information about the conditional isolated roots; computing a new material tree within an unchanged complete system gives no new root coverage. Root validation must check realness, box, node, pole, complete original Maxwell equations, model error, and numerical certification (when claimed).

If `v_i != 0`, material readout is

```math
z_i=\frac{w_i}{v_i}=\frac{w_i}{R_i+(wH)_i}.
```

If `w_i=v_i=0`, material readout is indeterminate and this is a *node*. Do not force division or discard it as an ordinary bad root; it may represent true continuous non-identifiability as long as resolvent remains invertible.

## 3. New source and quotient affine observable (NEW DERIVATION)

At the SAME frequency, SAME host, SAME receive row and SAME active support, let a physically produced new incident source give background total field `b` (k x 1) on that support, and background measured response `y0,b`.

Then its new data are

```math
y_b = y_{0,b} + h_b(c),\quad h_b(c) = (w_0 + cN)b = w_0b+cNb.
```

This requires the same material / reduced operator. A frequency, receiver, polarization, geometry, or host change is not covered by simply replacing b: rebuild the relevant operators and check the model.

For multiplication matrices `M_{c_l}`, a new-source observable has

```math
M_{h_b}=(w_0b)I+\sum_{\ell=1}^{s}(Nb)_\ell M_{c_\ell}.
```

The algebraic and source linearity are standard mathematics; the new work is to connect an exhaustive physically valid candidate set, accessible Bplus, and noise/model-error guarantees. When root coordinates are already available, evaluate h directly; multiplication matrices are not required for each candidate/source prediction.

## 4. Old-source-span impossibility (PROVEN UNDER MODEL)

For `b=B a`:

```math
Nb = NB a = 0, \quad h_b(c)=w_0Ba=ta.
```

Hence all exact old-data-equivalent roots respond identically to coherent combinations of already used sources. Repeated realizations can reduce noise but cannot distinguish *exact* branch responses. Regression test: draw random complex `a`, compare `h_{Ba}` across roots to `t a` and check `||N B a||` near numeric precision.

## 5. Separating finite regular roots (PROVEN UNDER CONDITIONS)

Assume the finite valid root set is covered and certified, with no node in the considered coordinates. Distinct real materials give distinct `w` and `c` in this chart. An actual new source library gives `Bplus` (k x L), `Cplus = N Bplus`. A realizable illumination coefficient vector `a` produces `b=Bplus a` (subject to actual hardware constraints).

For roots i and j:

```math
Delta_{ij}(a) = (c_i-c_j) Cplus a.
```

If `(c_i-c_j) Cplus != 0` for EVERY pair and the admissible coefficient set contains a nonempty complex open subset, each pair's nonseparating values form a proper hyperplane; a finite union cannot fill that set. Thus a generic **single new coherent source** separates the finite root set. `rank(Cplus)=s` is a convenient sufficient condition, not a necessary one for any given finite root set.

Caveats: (a) nonzero separation might be below noise and model discrepancy; (b) a discrete source-only menu may not contain a common separating source; (c) global material uniqueness does not follow; (d) a continuous family requires different treatment; (e) if `(c_i-c_j)Cplus=0`, no source from the specified span separates that pair at this fixed frequency and receiver.

## 6. Strong direct-completion baseline (PROVEN UNDER CONDITIONS)

If s more sources make `Bfull=[B Bplus]` square and invertible (`k=2s`), then

```math
w = t_{full} B_{full}^{-1},\quad z_i = w_i/[R_i+(wH)_i].
```

This does not need Q20 or GN; compare its energy, number of measurements, condition number, and robust error to branch enumeration + ONE additional source. Do not claim an algebraic advantage if multiple direct measurements are cheaper overall.

A local stability relation, for two admissible material states with `delta w=w'-w` and `delta z=z'-z`, is

```math
\delta w (I-HD_{z'}) = v(z)D_{\delta z}.
```

If `min_i |v_i(z)| >= nu`, `||I-HD_{z'}|| <= C`, `sigma_min(Bfull) >= beta`, then

```math
||\delta z||_2 <= [C/(nu*beta)] * ||\delta t_{full}||_2.
```

Constants and norms must refer to the actual discretized model and full-rank sources.

## 7. Nodes and continuous families (CONDITIONAL NEGATIVE RESULT)

When `v_i=w_i=0` and reduced physics stays regular, varying z_i can leave w and therefore every same-receiver / same-frequency illumination response unchanged. More old-kind illumination alone cannot resolve this direction. You may need another receiver, frequency, physics regime, or prior.

For a d-dimensional smooth REAL material fiber, each additional complex scalar measurement imposes at most two independent real scalar constraints. Therefore at least ceil(d/2) extra scalar complex measurements are necessary for local removal of d continuous freedoms, and tangent rank is additionally needed. Dimension counting alone never guarantees global uniqueness.

## 8. Uncertainty and coverage (NEW DESIGN; GLOBAL GUARANTEE NOT ACHIEVED)

The relevant feasible set under initial noise is

```math
F0={z in domain : ||Sigma0^(-1/2) [F0(z)-y0]|| <= tau0}.
```

Exhausting the isolated roots of the central equation does NOT exclude other noise-feasible regions, new components, merged roots, or singular-node neighborhoods. A claimed global coverage requires both certified local regions `Omega_j` and an exclusion bound on the complement:

```math
inf_{z in domain \ (union_j Omega_j)}
    ||Sigma0^(-1/2)(F0(z)-y0)|| > tau0.
```

With noise, the particular solution depends on t:

```math
w(t,c)=t B^dagger + cN, \quad h_b(t,c)=t B^dagger b + cNb.
```

Do not freeze w0 at the observed center when constructing uncertainty tubes. Predict a set or bound for every candidate tube.

Let each tube's whitened new-source prediction set lie in a ball with center mu_j and radius rho_j, with new measurement whitened noise radius tau_plus. A sufficient pairwise nonoverlap guarantee is

```math
||Sigma_plus^(-1/2)*(mu_i-mu_j)||
   > rho_i + rho_j + 2*tau_plus.
```

This is a sufficient geometric certificate, NOT a necessary condition for a useful statistical hypothesis test. If global feasible-set coverage is unavailable, describe results as separation of **found/certified local candidates**, not 'all possible materials'.

## 9. Contrast and PEC sanity checks (GENERAL NEGATIVE EXAMPLES)

- Single scalar `F(m)=a*m/(1-g*m)` is injective away from the pole for a != 0. Thus high contrast alone implies neither multiple roots nor algebraic advantage.
- Unknown PEC boundaries and surface currents follow boundary integral equations and `n x E_total=0`; original real finite-contrast Q20 does not carry over automatically.
- Two perfectly conducting closed bodies with the SAME external PEC surface but differing internal sealed voids give identical exterior Maxwell solutions under external excitation, assuming well-posed exterior scattering. There is no external recovery method within that model.
