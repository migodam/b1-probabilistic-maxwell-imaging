# 01 -- Research verdict, established evidence, and target selection

Read the complete Chinese report in `../reference/Z_ALG_Research_Report_2026-11-17.pdf`. This document is the compact operational decision memo, not a replacement.

## Unique main direction

**Finite, physically valid nonlinear Maxwell ambiguity coverage + active completion of missing measurements.** Begin with a known penetrable host, exactly 4-6 independent *active state-coordinate* real material parameters, a scalar 2D TM VIE at one frequency, and a single complex receive channel. Represent all valid conditional roots; use the dual quotient coordinate to predict real new-source signals; choose or reject new measurements under noise and hardware constraints.

Why: the previous root enumeration already showed a second valid nonlinear Maxwell material that 64-start Full-J missed. However, escalating to 12 and 576 unknown material pixels has NOT proved imaging recovery improvements due to algebraic enumeration. In R3, 538 new valid restricted candidates yielded no increase in physical recovery success. A large tree is unsupported by these findings.

The method's value may be a **negative** result: showing that no extra illumination in the accessible span could disambiguate, that noise envelopes overlap, or that actual source fields do not span the missing dual directions. All are useful if correctly certified.

## Evidence ledger -- historical facts, not freshly rerun

| ID | Status | Evidence / boundary | Code/record to audit |
|---|---|---|---|
| E1 | ARCHIVED_EXPERIMENT | 6-material `GENERAL6_00` two legal distinct roots via Q20; frozen 64-start Full-J found one. Both solvers found GT. Material RMS between algebra roots ~1.15879. Two full relative residuals ~1.94e-14 and ~1.71e-14. Additional root coverage, **not better GT recovery**. Solver says NOT_RIGOROUSLY_CERTIFIED. | `research/research_z_alg_r2`, including results, raw solver, COST_LEDGER |
| E2 | ARCHIVED_EXPERIMENT / LIMITED_CERTIFICATE | A local continuous equal-response real material family in an asymmetric discrete Maxwell example. Certification treats archived binary64 operators as exact constants. No proof of continuous-PDE or geometric/model uncertainty claim. | `research/research_z_alg_asymmetric_validation/MATHEMATICAL_PROOFS.md` |
| E3 | ARCHIVED_EXPERIMENT | R3 yielded 538 newly valid **conditional / restricted** local proposals; no best-full-residual or successful-reconstruction improvement. Some restricted targets are interpolated `y_S,tau = F_S(m) + tau*(y_S-F_S(m))`, tau in `{1, 0.5, 0.25, 0}`. Only tau=1 is the actual chosen measured subdata. | `research/research_z_alg_r3/audit/MECHANISM_AND_IMPLEMENTATION.md`, solver and validation |
| E4 | ARCHIVED_EXPERIMENT | 12-material corrector and 576-material GlobalDual / ordinary corrector outcomes cannot be credited to quotient-algebra root enumeration. | `research/research_z_alg_r3_digits`, `research/research_z_alg_r3` |
| E5 | ARCHIVED_EXPERIMENT | Wrong-basin and diversity experiments show that low response residual, physical target similarity and local solver convergence are distinct. | `research/research_z_alg_r4_basin`, `research/research_z_alg_r4_diversity` |
| E6 | ASSUMPTION / DERIVATION | Balanced acquisition of 2s real active state-coordinate materials and s independent complex illuminations; under required nondegeneracy, quotient length D = choose(2s,s), which grows combinatorially. This is NOT a cheap 576-variable model. | `research/research_z_alg_r2/theory/` |

Do not silently turn E1-E5 into proofs. Do not cite reconstructed summaries as if they were a reproduction by Codex.

## Physical target ranking

1. **Known penetrable host + 4-6 fixed real contrast DOFs**; exact discrete VIE, full multiple scattering. Original Q20 may apply if rank and nondegeneracy checked. Minimal test: a non-symmetric 6-material true double-root example plus a physically realizable separating source, under noise and independent forward validation. Highest near-term mathematical value.
2. **A few unknown loaded ports / compact scattering modules**; Maxwell/N-port or Foldy-Lax/T-matrix depending on physics. Finite rational structure is plausible, but Q20 re-derivation is required for parameter constraints and state rank. Minimal test: 4-6 scalar loading impedances with full-wave verification.
3. **Few localized cavities/shape parameters in known penetrable host**; VIE/BIE. Low number of geometry parameters does NOT make a low-degree Q20 system. Minimal test: two geometry-parametrized voids with explicit support/rank check.
4. **Known PEC body with a localized surface slot/crack**; EFIE/CFIE and changing boundaries. Original real-volume-contrast Q20 does NOT apply. New derivation required.
5. **Finite-conductivity metal NDT / shallow crack**; eddy currents and/or full Maxwell with skin effect, near-field probes, lift-off and complex conductivity. Valuable but expensive and beyond this first paper contract.
6. **Unknown pore topology or fully unknown voxel field**; no direct Q20 scalability. Stop by default.
7. **Closed perfect PEC body with different fully enclosed internal voids and identical exterior boundary**: externally invisible under ordinary exterior Maxwell boundary measurements by exterior uniqueness. Do not market as recoverable.

## Required physical clarifications

- A host with six scalar *regional* permittivities may have hundreds of changed VIE state entries. The determinant degree and active-state rank can be large even with only six geometry/material control parameters. Original Q20 applies to the required small state-coordinate structure, not automatically to each low-parameter geometry model.
- High contrast is not a sufficient condition for multiple material roots. `F(m) = a*m/(1-g*m)` is injective away from its pole (`a != 0`). High contrast may create both rich ambiguity AND severe model/solver conditioning.
- A closed PEC body with the same external surface cannot reveal strictly internal voids through external measurements; lossy finite conductivity, an aperture, internal probe, or other sensing modality changes the model and may change identifiability.
- Skin depth in a good conductor: `delta=sqrt(2/(omega*mu*sigma))`; this is attenuation, not an abrupt geometric visibility cutoff. Compare defects to skin depth, probe geometry, and noise.

## Priority order for outcomes

1. Mathematically valid non-identifiability or distinguishability statement under explicit assumptions.
2. Reproducible physical measurement design with a finite, noise-aware guarantee.
3. Measured/compute-cost improvement over direct source-basis completion and shared baseline algorithms.
4. Reconstruction quality if a unique branch actually becomes identifiable.

The project may end at 1 or 2 with a worthwhile negative study. It must NOT claim a 576-variable inversion breakthrough based on these gates.
