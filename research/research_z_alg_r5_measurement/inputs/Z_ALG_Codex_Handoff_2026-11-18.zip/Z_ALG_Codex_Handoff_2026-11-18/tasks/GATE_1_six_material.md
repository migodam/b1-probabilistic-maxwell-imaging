# Gate 1 -- 4-6 real material unknowns: physical ambiguity -> extra illumination

Do not start this stage before Gate 0. Pilot the archived `GENERAL6_00` only for development. Freeze new targets and online rules BEFORE evaluating any hidden GT. Maximum new targets: 6. No large scan.

## A. Mathematical identity unit tests

| Test | Construction | Expected / falsification |
|---|---|---|
| A1 reduced physics | random regular bounded z, several physically simulated sources | `F_full(z)-F_host` equals `R(I-Dz H)^(-1) Dz B` within independent forward numeric error |
| A2 dual identity | valid numerical z | `wB=t`, `w_i=z_i(R_i+(wH)_i)` |
| A3 old-span test | arbitrary complex a, b=B a | `N b=0`; ALL exact old-data roots give h_b=t a |
| A4 new-field test | b generated through physical source API, same frequency/host/receiver | `y_new_full(z)-y0_new` matches `w b` for EVERY archived legal root |
| A5 direct completion | additional s independent physical fields | if `Bfull` invertible, recover w and z; record conditioning and noise response |
| A6 nodes / poles | deliberately constructed or archived pathological cases | no unsafe division; separate root / node / resolvent status |
| A7 rank / source feasibility | old span and inaccessible source dictionary | correctly mark cannot distinguish; do not use arbitrary support-space b |
| A8 noise center motion | perturbed old data t | use w(t,c)=t Bdagger+cN; center-frozen w0 implementation must fail a regression |

## B. Candidate generation and physical acceptance

- Reuse audited R2 quotient computation. Inspect and log ALL complex branches including failures and multiplicitiy. If root completeness is unproven, mark it as such.
- Repeat using an independent mature homotopy implementation with comparable certification and computational cost; compare root coverage, not only best objective value.
- Budget-matched 64-start Full-J/TRF and reciprocal TRF use identical full physical forward and admissibility checks.
- Full Maxwell state + measured data residual required, including all old illuminations. Track local proposal tau from R3 only as a negative control, not an accepted true-data root by default.
- Deduplicate using numerical material tolerance separately from actual observation-distance and topology.
- For a double-root example, log both material vectors, pair material distance, full response difference, root residual, condition, node margin, realness and physical certificate status.

## C. Physical new-source design

- Build frozen source menu from actual transmitter excitations at same frequency, same receiver and same host, at most 48 alternatives; optionally include a few power-controlled physically realizable coherent mixtures.
- Compute `Cplus = N Bplus`. Confirm that physically generated old-span combinations have zero new information.
- For every root pair, pretest `(ci-cj) Cplus`. If zero for all accessible fields, report `INACCESSIBLE_DIFFERENCE` -- no optimization may falsely claim to overcome it.
- Compute conservative whitened predicted separation accounting for uncertainty in initial t, finite material tubes, model discrepancy and new-measurement noise.
- Compare the fixed single-source design to random/fixed coherent sources, same source budget; if a noise-aware certificate is unavailable, do not call a nonzero mean difference successful disambiguation.
- Independently full-forward-simulate chosen source for each legal root to validate the affine observable, and log errors.
- Include the `s extra sources -> invertible Bfull -> direct w -> z` comparator with identical physics/power/error accounting.

## D. Statistical and online policy

- Output one of: `ONE_BRANCH`, `MULTIPLE_COMPATIBLE`, or `UNDETERMINED` with an explicit coverage/certificate label.
- A source may be selected using only the candidate-set predictions and declared noise/energy/cost. Never select it by which one is GT.
- Hold-out GT only for a post-hoc analysis of material reconstruction, no best@K oracle claim.
- If the initial data are exactly nonidentifying, explain why any old-data-only selector fails.

## E. Minimal readout

Each new target must report:

- Root counts by algebra length, approximate complex roots, real roots, material valid, full data valid, certified isolated, unresolved and duplicated.
- Whether the set is proved exhaustive in an exact system, locally certified, or unknown over the full noise ball.
- Physics errors: old data, new-source dual vs full VIE, material box, poles/nodes, mesh discrepancy if available.
- Candidate separation: min pair distance, predicted/observed margin, source feasibility, cases impossible under the accessible span.
- Direct-completion comparator rank/conditioning and measurement count.
- Physics cost: total LU, RHS, reduced solves, eigenvalues, homotopy paths, TRF steps, independent forward checks, precision escalation, memory, CPU.
- Final post-hoc material error and branch/outcome metrics (but GT was hidden during decisions).

## Hard STOP / NO-GO

Any of:

1. no physically accessible source separates the known valid double root;
2. all accessible separation is below noise/model-discrepancy budget;
3. conditional root coverage and tube validity cannot be established in budget for the claim being made;
4. proposed design is strictly dominated in acquisition / scientific cost by simple source-basis completion or strong homotopy/TRF controls;
5. there is no capability beyond the already known 'more independent measurements help' qualitative point.

If no new branch is covered by the candidate generators, this is a negative result; log it and do not replace the target without re-freezing the protocol.

## Resource limits

- <= 6 new targets, <= 48 source-menu items.
- Candidate discovery <= 60 seconds per target per method, plus separately recorded frozen 64-start TRF reference.
- Certification / noise-cover work <= 10 minutes per target total.
- High precision: only 64 -> 128 -> 256 bit levels (max 2 upgrades).
- Peak process memory <= 8 GiB; Gate 1 aggregate <= 2 CPU hours.
- Cost counters and environmental information must be saved even on failure.
