# Gate 0 -- source audit & frozen protocol (READ-ONLY SCIENCE)

**Goal:** ensure the working repo's actual formulas, code paths, result files and root labels match the archived research report. This must precede any new numerical claim.

## Inputs

- The user's `b1-probabilistic-maxwell-imaging` checkout.
- This package's `reference/Z_ALG_Research_Report_2026-11-17.pdf`.
- Historical reference commit `55724cb1a7bafbd9afa3b95ac817522f8dcaf2d0`.
- Source map in `docs/06_repo_audit_map.md`.

## Required inspections

- Verify 2D scalar-TM discretization, Green convention, source/receiver normalization and forward identity `A(m) = I-D_mG` used by code.
- Read full active-code execution paths for general quotient, algebraic root extraction, lifting real materials, multistart TRF, reciprocal material parameterization and complete physics validation.
- Check exact Q6/Q20 assumptions: supported system sizes, B rank, T invertibility, finite quotient length, nodes, poles, realness and box validation.
- Record `GENERAL6_00` double root, archived holdout root counts and whether any independent certifier is available.
- Read R3 proposal generation: tau interpolation, active subset/support, frozen complement, full residual after correction, oracle vs online ranking, failure reports and actual chosen best candidate.
- Inspect R3 digits, GlobalDual and R4 basin/diversity failures; separate code responsibility and attributable algorithmic gains.
- Check whether current repo HEAD changes validations or data after the archival reference. Do not overwrite archives; isolate experiments.
- Confirm physically realizable source API: how incident fields are generated from actual transmitters, power normalization, receive response, and how additional same-frequency sources are simulated.
- Check forward error tolerance vs discretization error and whether higher-res validation exists.

## Outputs (no new parameter scan)

1. `PROVENANCE_AUDIT.md` including recorded actual commit, paths and line-level code pointers.
2. `MODEL_CONTRACT.md` explaining all array shapes, transposes and normalization.
3. `FROZEN_PROTOCOL.md`: 6-target maximum, sources, noise, model discrepancy, baselines, budgets, pass/fail thresholds, source menu and GT quarantine.
4. A short list of discrepancies between code and this handoff, if any; propose the smallest scientifically justified correction before editing code.

## Gate 0 pass condition

All relevant formulas and actual source-file APIs are traced, historical results are not conflated with fresh reproduction, and scientific thresholds are fixed without accessing held-out GT. A disagreement requiring a change of physics or proof contract blocks Gate 1 until resolved.
