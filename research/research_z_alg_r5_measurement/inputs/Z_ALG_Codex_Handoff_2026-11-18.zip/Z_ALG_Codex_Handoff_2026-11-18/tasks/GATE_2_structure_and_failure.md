# Gate 2 -- conditional only: 12-48-state structure and R3 counterexample

**DO NOT EXECUTE without explicit user instruction after a Gate-1 decision.** This file exists to preserve a falsifiable next-step design.

## Two contrasting groups (<=4 total targets)

**Group G: valid low-dimensional support.** Full physical state dimension 12 or 48, but only 4-6 physically active independent material state coordinates are unknown. Known host complement is truly known. Q20 may be reused only if original assumptions continue to hold. Explicitly label this as *4-6 unknown DOFs embedded in a larger known system*, NOT solving 48 unknown materials algebraically.

**Group F: genuine support misspecification.** 12 independent material coordinates unknown or a deliberately wrong frozen complement. Reproduce the R3 failure mode. Only one fixed-budget restricted Q6 -> full TRF branch attempt, compared with strong same-budget multistart. The correct material may lie outside the chosen conditional affine slice.

## Cost probe (not success search)

Once, and only if budget permits, probe a full 12-independent-material quotient with k=12, s=6, D=924. Log memory, conditioning and time to partial completion. Stop at 10 minutes or 8 GiB; never build a repeated online branch engine from one promising result.

## Independent physics

Predefine one deliberate small host mismatch / finer-mesh validation. If the discrepancy invalidates the claimed certificate or stable source separation, revoke that claim. Do not tune error tolerance after inspecting hidden GT.

## Baselines and success criteria

Controls: shared host LU and source dictionary; mature homotopy, full multistart TRF, reciprocal TRF, Q-based enumeration, independent full physics validation, and source basis completion. Keep all failures, support mismatch and precision exhaustion.

A continuation beyond Gate 2 requires a physically meaningful distinguishability or recovery benefit under frozen compute AND measurement budget, while remaining honest about incomplete noise-ball coverage and model discrepancy. A large-scale 576-material search is not automatically authorized.

## Hard limits

- <= 4 targets, <= 4 CPU hours for the stage.
- One full-12 cost probe <= 10 minutes and <= 8 GiB.
- Use exactly one predefined modeling discrepancy setting, not a tuning scan.
