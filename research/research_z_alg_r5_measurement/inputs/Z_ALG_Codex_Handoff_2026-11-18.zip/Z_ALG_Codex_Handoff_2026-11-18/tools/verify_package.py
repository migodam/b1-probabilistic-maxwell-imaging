#!/usr/bin/env python3
"""Offline integrity and syntax checker for the Z-ALG Codex handoff.

Usage: python3 tools/verify_package.py
Requires Python standard library only. Does NOT validate mathematical claims.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent.parent
MANIFEST = BASE / "MANIFEST.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    if not MANIFEST.exists():
        print("FAIL: MANIFEST.json missing")
        return 2
    doc = json.loads(MANIFEST.read_text(encoding="utf-8"))
    expected = doc["files"]
    bad = []
    for item in expected:
        relative = Path(item["path"])
        if relative.is_absolute() or ".." in relative.parts:
            bad.append(f"unsafe path: {relative}")
            continue
        path = BASE / relative
        if not path.is_file():
            bad.append(f"missing: {relative}")
            continue
        if path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
            bad.append(f"size/hash mismatch: {relative}")
    actual = {p.relative_to(BASE).as_posix() for p in BASE.rglob("*") if p.is_file() and p != MANIFEST}
    listed = {item["path"] for item in expected}
    for relative in sorted(actual - listed):
        bad.append(f"unlisted file: {relative}")
    for relative in sorted(listed - actual):
        bad.append(f"listed but absent: {relative}")
    for path in sorted(BASE.rglob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            bad.append(f"invalid JSON: {path.relative_to(BASE)}: {exc}")
    required = [
        "README.md", "AGENTS.md", "CODEX_START_HERE.md",
        "docs/02_math_contract.md", "contracts/experiment_plan.json",
        "contracts/record_schema.json",
        "reference/Z_ALG_Research_Report_2026-11-17.pdf",
    ]
    for path in required:
        if not (BASE / path).is_file():
            bad.append(f"required file missing: {path}")
    if bad:
        print("FAILED integrity checks:")
        print("\n".join(bad))
        return 1
    print(f"PASS: {len(expected)} hashed files, valid JSON, required entrypoints present")
    print("This does NOT certify Maxwell root coverage or research correctness.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
